package com.smartcity.service;

import com.smartcity.algorithm.PathResult;
import com.smartcity.ds.MaxHeap;
import com.smartcity.model.Incident;
import com.smartcity.model.enums.IncidentStatus;
import com.smartcity.model.enums.IncidentType;
import com.smartcity.model.enums.RouteMode;
import com.smartcity.model.enums.Severity;
import com.smartcity.repository.IncidentRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Incident management service.
 *
 * <p>Incidents are prioritised through an explicitly implemented
 * {@link MaxHeap max-heap} ordered by severity (descending), with report time
 * (ascending) as the tie-breaker. Higher-severity incidents are therefore
 * processed first; among equal severity, the earliest-reported incident wins.</p>
 *
 * <p><strong>Disclaimer:</strong> this is an academic simulation and is not
 * connected to real emergency dispatch services.</p>
 */
@Service
public class IncidentService {

    private final IncidentRepository incidentRepository;
    private final RouteService routeService;

    public IncidentService(IncidentRepository incidentRepository, RouteService routeService) {
        this.incidentRepository = incidentRepository;
        this.routeService = routeService;
    }

    public List<Incident> findAll() {
        return incidentRepository.findAll();
    }

    public Optional<Incident> findById(String id) {
        return incidentRepository.findById(id);
    }

    public Incident save(Incident incident) {
        if (incident.getReportedTime() == null) {
            incident.setReportedTime(LocalDateTime.now());
        }
        if (incident.getStatus() == null) {
            incident.setStatus(IncidentStatus.REPORTED);
        }
        return incidentRepository.save(incident);
    }

    public void deleteById(String id) {
        incidentRepository.deleteById(id);
    }

    public List<Incident> filter(IncidentType type, Severity severity, IncidentStatus status) {
        List<Incident> all = incidentRepository.findAll();
        List<Incident> out = new ArrayList<>();
        for (Incident i : all) {
            if (type != null && i.getType() != type) continue;
            if (severity != null && i.getSeverity() != severity) continue;
            if (status != null && i.getStatus() != status) continue;
            out.add(i);
        }
        return out;
    }

    /**
     * Return incidents ordered by priority using a max-heap: severity desc,
     * then reportedTime asc.
     */
    public List<Incident> priorityOrder() {
        List<Incident> all = incidentRepository.findAll();
        if (all.isEmpty()) {
            return List.of();
        }
        // Max-heap: higher severity = greater (polled first); among equal
        // severity, earlier reported time = greater (polled first).
        Comparator<Incident> cmp = Comparator
                .comparingInt((Incident i) -> i.getSeverity().priority())
                .thenComparing(Comparator.comparing(Incident::getReportedTime).reversed());
        MaxHeap<Incident> heap = new MaxHeap<>(all.size(), cmp);
        for (Incident i : all) {
            heap.add(i);
        }
        List<Incident> ordered = new ArrayList<>();
        while (!heap.isEmpty()) {
            ordered.add(heap.poll());
        }
        return ordered;
    }

    public List<Incident> activeIncidents() {
        return incidentRepository.findByStatusNot(IncidentStatus.RESOLVED);
    }

    /**
     * Calculate a sample emergency route from the nearest depot (J-01) to the
     * incident location using fastest-time mode. Demonstrates integration
     * between incident management and routing.
     */
    public PathResult emergencyRoute(String incidentId) {
        Optional<Incident> opt = incidentRepository.findById(incidentId);
        if (opt.isEmpty() || opt.get().getJunctionId() == null) {
            return null;
        }
        String depot = "J-01";
        return routeService.buildGraph() != null
                ? com.smartcity.algorithm.Dijkstra.shortestPath(
                        routeService.buildGraph(), depot, opt.get().getJunctionId(),
                        com.smartcity.algorithm.Dijkstra.timeWeight())
                : null;
    }
}
