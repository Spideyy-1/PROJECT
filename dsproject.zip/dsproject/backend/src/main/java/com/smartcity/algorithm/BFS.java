package com.smartcity.algorithm;

import com.smartcity.ds.ArrayStack;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Breadth-First Search traversal and connected-components computation over the
 * road {@link Graph}. Uses a {@link Deque} as the FIFO queue.
 */
public final class BFS {

    private BFS() {
    }

    /**
     * Traverse the graph from {@code start} in breadth-first order, visiting
     * only reachable (non-closed) vertices.
     */
    public static List<String> traverse(Graph graph, String start) {
        List<String> order = new ArrayList<>();
        if (!graph.containsVertex(start)) {
            return order;
        }
        Set<String> visited = new HashSet<>();
        Deque<String> queue = new ArrayDeque<>();
        queue.add(start);
        visited.add(start);
        while (!queue.isEmpty()) {
            String u = queue.poll();
            order.add(u);
            for (Edge e : graph.getNeighbors(u)) {
                if (!visited.contains(e.getTo())) {
                    visited.add(e.getTo());
                    queue.add(e.getTo());
                }
            }
        }
        return order;
    }

    /**
     * Compute connected components of the graph (over available edges).
     * Each component is a list of vertex IDs.
     */
    public static List<List<String>> connectedComponents(Graph graph) {
        List<List<String>> components = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        for (String v : graph.getVertices()) {
            if (!visited.contains(v)) {
                List<String> comp = traverse(graph, v);
                components.add(comp);
                visited.addAll(comp);
            }
        }
        return components;
    }

    /**
     * Iterative DFS using the custom {@link ArrayStack} (demonstrates the
     * stack data structure). Returns depth-first traversal order.
     */
    public static List<String> dfsIterative(Graph graph, String start) {
        List<String> order = new ArrayList<>();
        if (!graph.containsVertex(start)) {
            return order;
        }
        Set<String> visited = new HashSet<>();
        ArrayStack<String> stack = new ArrayStack<>(graph.vertexCount() + 1);
        stack.push(start);
        while (!stack.isEmpty()) {
            String u = stack.pop();
            if (visited.contains(u)) {
                continue;
            }
            visited.add(u);
            order.add(u);
            // Push neighbors in reverse so the first neighbor is popped first.
            List<Edge> neighbors = graph.getNeighbors(u);
            Collections.reverse(neighbors);
            for (Edge e : neighbors) {
                if (!visited.contains(e.getTo())) {
                    stack.push(e.getTo());
                }
            }
        }
        return order;
    }
}
