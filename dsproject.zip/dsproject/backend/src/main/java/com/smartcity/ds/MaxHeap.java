package com.smartcity.ds;

import java.util.Comparator;
import java.util.NoSuchElementException;

/**
 * A binary max-heap priority queue backed by an array.
 * <p>
 * The element with the <em>highest</em> priority (per the supplied comparator)
 * is dequeued first. This is used for incident management where higher
 * severity incidents must be processed first, with report time as a
 * tie-breaker (earlier reported first among equal severity).
 * </p>
 * <p>
 * Implemented explicitly rather than using {@link java.util.PriorityQueue} to
 * demonstrate the heap data structure.
 * </p>
 *
 * @param <T> element type
 */
public class MaxHeap<T> {

    private final Object[] heap;
    private final Comparator<? super T> comparator;
    private int size;
    private final int capacity;

    public MaxHeap(int capacity, Comparator<? super T> comparator) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be positive");
        }
        this.capacity = capacity;
        this.heap = new Object[capacity];
        this.comparator = comparator;
    }

    public void add(T element) {
        if (size == capacity) {
            throw new IllegalStateException("Heap is full");
        }
        heap[size] = element;
        siftUp(size);
        size++;
    }

    @SuppressWarnings("unchecked")
    public T peek() {
        if (size == 0) {
            throw new NoSuchElementException("Heap is empty");
        }
        return (T) heap[0];
    }

    public T poll() {
        if (size == 0) {
            throw new NoSuchElementException("Heap is empty");
        }
        @SuppressWarnings("unchecked")
        T top = (T) heap[0];
        size--;
        heap[0] = heap[size];
        heap[size] = null;
        if (size > 0) {
            siftDown(0);
        }
        return top;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    private void siftUp(int index) {
        while (index > 0) {
            int parent = (index - 1) / 2;
            if (compare(index, parent) > 0) {
                swap(index, parent);
                index = parent;
            } else {
                break;
            }
        }
    }

    private void siftDown(int index) {
        while (true) {
            int left = 2 * index + 1;
            int right = 2 * index + 2;
            int largest = index;
            if (left < size && compare(left, largest) > 0) {
                largest = left;
            }
            if (right < size && compare(right, largest) > 0) {
                largest = right;
            }
            if (largest == index) {
                break;
            }
            swap(index, largest);
            index = largest;
        }
    }

    @SuppressWarnings("unchecked")
    private int compare(int a, int b) {
        return comparator.compare((T) heap[a], (T) heap[b]);
    }

    private void swap(int a, int b) {
        Object tmp = heap[a];
        heap[a] = heap[b];
        heap[b] = tmp;
    }
}
