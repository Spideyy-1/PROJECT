package com.smartcity.algorithm;

/**
 * A weighted directed edge in the road graph. Roads are treated as
 * undirected, so each road produces two {@code Edge} instances (one per
 * direction) in the adjacency list.
 */
public class Edge {

    private final String from;
    private final String to;
    private final double distanceKm;
    private final double timeMinutes;
    private final double congestionLevel;
    private final boolean available;
    private final String roadId;

    public Edge(String from, String to, double distanceKm, double timeMinutes,
                double congestionLevel, boolean available, String roadId) {
        this.from = from;
        this.to = to;
        this.distanceKm = distanceKm;
        this.timeMinutes = timeMinutes;
        this.congestionLevel = congestionLevel;
        this.available = available;
        this.roadId = roadId;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public double getDistanceKm() {
        return distanceKm;
    }

    public double getTimeMinutes() {
        return timeMinutes;
    }

    public double getCongestionLevel() {
        return congestionLevel;
    }

    public boolean isAvailable() {
        return available;
    }

    public String getRoadId() {
        return roadId;
    }
}
