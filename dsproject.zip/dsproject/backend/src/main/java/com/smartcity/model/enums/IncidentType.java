package com.smartcity.model.enums;

/** Supported incident types. */
public enum IncidentType {
    ROAD_ACCIDENT,
    VEHICLE_BREAKDOWN,
    ROAD_CLOSURE,
    HEAVY_CONGESTION,
    EMERGENCY_VEHICLE_REQUEST
}
