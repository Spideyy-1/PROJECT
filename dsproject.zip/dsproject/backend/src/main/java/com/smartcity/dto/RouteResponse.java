package com.smartcity.dto;

import java.util.List;

/**
 * Response body for a calculated route.
 */
public record RouteResponse(
        boolean reachable,
        List<String> junctions,
        List<String> roadIds,
        double totalDistanceKm,
        double totalTimeMinutes,
        String mode,
        String reason,
        List<AlternativeRoute> alternatives
) {
    public record AlternativeRoute(
            String mode,
            List<String> junctions,
            double totalDistanceKm,
            double totalTimeMinutes
    ) {
    }
}
