package com.smartcity.controller;

import com.smartcity.dto.RouteWithStops;
import com.smartcity.model.BusRoute;
import com.smartcity.service.TransportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transport")
public class TransportController {

    private final TransportService transportService;

    public TransportController(TransportService transportService) {
        this.transportService = transportService;
    }

    @GetMapping("/routes")
    public List<RouteWithStops> routes() {
        return transportService.allRoutesWithStops();
    }

    @GetMapping("/routes/{id}")
    public ResponseEntity<RouteWithStops> route(@PathVariable String id) {
        RouteWithStops r = transportService.routeWithStops(id);
        return r == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(r);
    }

    @GetMapping("/routes/{id}/arrival")
    public ResponseEntity<String> nextArrival(@PathVariable String id) {
        if (transportService.findRoute(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(transportService.nextArrival(id));
    }
}
