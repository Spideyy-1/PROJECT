package com.smartcity.ds;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A minimal singly linked list used to store ordered sequences such as bus
 * route stops. Implemented from scratch (rather than using
 * {@link java.util.LinkedList}) to demonstrate the data structure explicitly.
 *
 * @param <T> element type
 */
public class LinkedList<T> implements Iterable<T> {

    private static class Node<T> {
        T value;
        Node<T> next;

        Node(T value) {
            this.value = value;
        }
    }

    private Node<T> head;
    private Node<T> tail;
    private int size;

    public LinkedList() {
    }

    /** Append an element to the end (O(1) thanks to the tail pointer). */
    public void add(T value) {
        Node<T> node = new Node<>(value);
        if (tail == null) {
            head = tail = node;
        } else {
            tail.next = node;
            tail = node;
        }
        size++;
    }

    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " out of bounds for size " + size);
        }
        Node<T> cur = head;
        for (int i = 0; i < index; i++) {
            cur = cur.next;
        }
        return cur.value;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public T first() {
        if (head == null) {
            throw new NoSuchElementException("List is empty");
        }
        return head.value;
    }

    public T last() {
        if (tail == null) {
            throw new NoSuchElementException("List is empty");
        }
        return tail.value;
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<>() {
            private Node<T> cur = head;

            @Override
            public boolean hasNext() {
                return cur != null;
            }

            @Override
            public T next() {
                if (cur == null) {
                    throw new NoSuchElementException();
                }
                T v = cur.value;
                cur = cur.next;
                return v;
            }
        };
    }

    public java.util.List<T> toList() {
        java.util.List<T> out = new java.util.ArrayList<>(size);
        for (T v : this) {
            out.add(v);
        }
        return out;
    }
}
