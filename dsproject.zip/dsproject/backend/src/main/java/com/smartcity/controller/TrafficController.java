package com.smartcity.controller;

import com.smartcity.model.Road;
import com.smartcity.service.TrafficService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/traffic")
public class TrafficController {

    private final TrafficService trafficService;

    public TrafficController(TrafficService trafficService) {
        this.trafficService = trafficService;
    }

    @GetMapping("/kpis")
    public Map<String, Object> kpis() {
        return trafficService.getKpis();
    }

    @GetMapping("/junctions")
    public List<Map<String, Object>> junctionStatuses() {
        return trafficService.allJunctionStatuses();
    }

    @GetMapping("/junctions/{id}")
    public Map<String, Object> junctionStatus(@PathVariable String id) {
        double congestion = trafficService.junctionCongestion(id);
        return Map.of(
                "id", id,
                "congestion", congestion,
                "state", trafficService.trafficState(congestion),
                "averageSpeedKmh", Math.round(trafficService.junctionAverageSpeed(id)),
                "density", trafficService.junctionDensity(id),
                "connectedRoads", trafficService.connectedRoads(id).stream().map(Road::getId).toList()
        );
    }
}
