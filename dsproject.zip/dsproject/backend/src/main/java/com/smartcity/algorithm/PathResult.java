package com.smartcity.algorithm;

import java.util.List;

/**
 * Result of a shortest-path computation.
 */
public class PathResult {

    private final List<String> junctions;   // ordered junction IDs source -> dest
    private final List<String> roadIds;     // ordered road IDs used
    private final double totalDistanceKm;
    private final double totalTimeMinutes;
    private final boolean reachable;

    public PathResult(List<String> junctions, List<String> roadIds,
                      double totalDistanceKm, double totalTimeMinutes, boolean reachable) {
        this.junctions = junctions;
        this.roadIds = roadIds;
        this.totalDistanceKm = totalDistanceKm;
        this.totalTimeMinutes = totalTimeMinutes;
        this.reachable = reachable;
    }

    public List<String> getJunctions() {
        return junctions;
    }

    public List<String> getRoadIds() {
        return roadIds;
    }

    public double getTotalDistanceKm() {
        return totalDistanceKm;
    }

    public double getTotalTimeMinutes() {
        return totalTimeMinutes;
    }

    public boolean isReachable() {
        return reachable;
    }
}
