package com.smartcity.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

/**
 * A road-network junction (graph vertex). Identified by a short code
 * (e.g. {@code J-01}) and placed on the map by latitude/longitude.
 */
@Entity
@Table(name = "junction")
public class Junction {

    @Id
    private String id;

    @NotNull
    private String name;

    private double lat;
    private double lon;

    public Junction() {
    }

    public Junction(String id, String name, double lat, double lon) {
        setId(id);
        setName(name);
        this.lat = lat;
        this.lon = lon;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Junction id must not be blank");
        }
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Junction name must not be blank");
        }
        this.name = name;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLon() {
        return lon;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

    @Override
    public String toString() {
        return "Junction{id='" + id + "', name='" + name + "'}";
    }
}
