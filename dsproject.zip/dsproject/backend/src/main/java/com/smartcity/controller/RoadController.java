package com.smartcity.controller;

import com.smartcity.model.Road;
import com.smartcity.repository.RoadRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/roads")
public class RoadController {

    private final RoadRepository repository;

    public RoadController(RoadRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Road> getAll() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Road> getById(@PathVariable String id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Road create(@RequestBody Road road) {
        return repository.save(road);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Road> update(@PathVariable String id, @RequestBody Road road) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        road.setId(id);
        return ResponseEntity.ok(repository.save(road));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
