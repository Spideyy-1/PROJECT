package com.smartcity.repository;

import com.smartcity.model.Incident;
import com.smartcity.model.enums.IncidentStatus;
import com.smartcity.model.enums.IncidentType;
import com.smartcity.model.enums.Severity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IncidentRepository extends JpaRepository<Incident, String> {
    List<Incident> findBySeverity(Severity severity);
    List<Incident> findByStatus(IncidentStatus status);
    List<Incident> findByType(IncidentType type);
    List<Incident> findByStatusNot(IncidentStatus status);
}
