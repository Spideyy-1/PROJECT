package com.smartcity.controller;

import com.smartcity.algorithm.BFS;
import com.smartcity.algorithm.DFS;
import com.smartcity.algorithm.Graph;
import com.smartcity.service.RouteService;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/graph")
public class GraphController {

    private final RouteService routeService;

    public GraphController(RouteService routeService) {
        this.routeService = routeService;
    }

    @GetMapping
    public Map<String, Object> graph() {
        Graph g = routeService.buildGraph();
        Map<String, Object> out = new HashMap<>();
        out.put("vertices", g.vertexCount());
        out.put("edges", g.edgeCount());
        out.put("junctionIds", g.getVertices());
        return out;
    }

    @GetMapping("/bfs")
    public List<String> bfs(@RequestParam String start) {
        return BFS.traverse(routeService.buildGraph(), start);
    }

    @GetMapping("/dfs")
    public List<String> dfs(@RequestParam String start) {
        return DFS.traverse(routeService.buildGraph(), start);
    }

    @GetMapping("/components")
    public List<List<String>> components() {
        return BFS.connectedComponents(routeService.buildGraph());
    }
}
