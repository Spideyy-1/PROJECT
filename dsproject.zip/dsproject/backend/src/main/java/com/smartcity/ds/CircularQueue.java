package com.smartcity.ds;

import java.util.NoSuchElementException;

/**
 * A fixed-capacity circular (ring-buffer) FIFO queue backed by an array.
 * Used for the recent-events feed.
 */
public class CircularQueue<T> {

    private final Object[] buffer;
    private int head;
    private int tail;
    private int size;

    public CircularQueue(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be positive");
        }
        this.buffer = new Object[capacity];
    }

    public void enqueue(T value) {
        if (size == buffer.length) {
            throw new IllegalStateException("Queue is full");
        }
        buffer[tail] = value;
        tail = (tail + 1) % buffer.length;
        size++;
    }

    @SuppressWarnings("unchecked")
    public T dequeue() {
        if (size == 0) {
            throw new NoSuchElementException("Queue is empty");
        }
        T v = (T) buffer[head];
        buffer[head] = null;
        head = (head + 1) % buffer.length;
        size--;
        return v;
    }

    @SuppressWarnings("unchecked")
    public T peek() {
        if (size == 0) {
            throw new NoSuchElementException("Queue is empty");
        }
        return (T) buffer[head];
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
}
