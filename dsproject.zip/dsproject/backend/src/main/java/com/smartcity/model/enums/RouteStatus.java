package com.smartcity.model.enums;

/** Operational status of a bus route. */
public enum RouteStatus {
    ON_TIME,
    DELAYED,
    SUSPENDED
}
