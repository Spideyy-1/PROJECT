package com.smartcity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * SMART CITY — Traffic &amp; Public Transport Management System.
 *
 * <p>Entry point for the Spring Boot REST backend. The application models an
 * urban road network as a weighted graph and exposes REST APIs for traffic
 * monitoring, route planning (Dijkstra), incident management (priority queue),
 * public transport (ordered linked-list stops) and analytics.</p>
 *
 * <p>Academic demonstration — all data is simulated.</p>
 */
@SpringBootApplication
public class SmartCityApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartCityApplication.class, args);
    }
}
