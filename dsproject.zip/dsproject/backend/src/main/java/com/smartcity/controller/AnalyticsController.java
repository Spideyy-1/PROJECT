package com.smartcity.controller;

import com.smartcity.service.AnalyticsService;
import com.smartcity.service.RouteService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/analytics")
public class AnalyticsController {

    private final AnalyticsService analyticsService;
    private final RouteService routeService;

    public AnalyticsController(AnalyticsService analyticsService, RouteService routeService) {
        this.analyticsService = analyticsService;
        this.routeService = routeService;
    }

    @GetMapping("/congestion-distribution")
    public Map<String, Integer> congestionDistribution() {
        return analyticsService.congestionDistribution();
    }

    @GetMapping("/speed-by-road")
    public List<Map<String, Object>> speedByRoad() {
        return analyticsService.averageSpeedByRoad();
    }

    @GetMapping("/incidents-by-type")
    public Map<String, Integer> incidentsByType() {
        return analyticsService.incidentsByType();
    }

    @GetMapping("/incidents-by-severity")
    public Map<String, Integer> incidentsBySeverity() {
        return analyticsService.incidentsBySeverity();
    }

    @GetMapping("/most-congested-junctions")
    public List<Map<String, Object>> mostCongested(@RequestParam(defaultValue = "10") int limit) {
        return analyticsService.mostCongestedJunctions(limit);
    }

    @GetMapping("/road-utilization")
    public Map<String, Object> roadUtilization() {
        return analyticsService.roadUtilization();
    }

    @GetMapping("/incidents-over-time")
    public Map<String, Object> incidentsOverTime() {
        return analyticsService.incidentsOverTime();
    }

    @GetMapping("/distance-vs-time")
    public Map<String, Object> distanceVsTime() {
        return analyticsService.distanceVsTime(routeService);
    }
}
