package com.smartcity.dto;

import com.smartcity.model.enums.RouteMode;

/**
 * Request body for route calculation.
 */
public record RouteRequest(
        String source,
        String destination,
        RouteMode mode
) {
}
