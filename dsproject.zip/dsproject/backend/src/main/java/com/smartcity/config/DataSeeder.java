package com.smartcity.config;

import com.smartcity.model.BusRoute;
import com.smartcity.model.BusStop;
import com.smartcity.model.Incident;
import com.smartcity.model.Junction;
import com.smartcity.model.Road;
import com.smartcity.model.Vehicle;
import com.smartcity.model.enums.IncidentStatus;
import com.smartcity.model.enums.IncidentType;
import com.smartcity.model.enums.RouteStatus;
import com.smartcity.model.enums.Severity;
import com.smartcity.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * Seeds the sample road network on startup.
 *
 * <p>The network is a 6×4 grid of 24 junctions with 42 roads (20 horizontal,
 * 18 vertical, 4 diagonal). All values are illustrative demo data for an
 * academic simulation.</p>
 */
@Component
public class DataSeeder implements CommandLineRunner {

    private final JunctionRepository junctionRepo;
    private final RoadRepository roadRepo;
    private final VehicleRepository vehicleRepo;
    private final BusRouteRepository routeRepo;
    private final BusStopRepository stopRepo;
    private final IncidentRepository incidentRepo;

    public DataSeeder(JunctionRepository junctionRepo, RoadRepository roadRepo,
                      VehicleRepository vehicleRepo, BusRouteRepository routeRepo,
                      BusStopRepository stopRepo, IncidentRepository incidentRepo) {
        this.junctionRepo = junctionRepo;
        this.roadRepo = roadRepo;
        this.vehicleRepo = vehicleRepo;
        this.routeRepo = routeRepo;
        this.stopRepo = stopRepo;
        this.incidentRepo = incidentRepo;
    }

    @Override
    public void run(String... args) {
        seedJunctions();
        seedRoads();
        seedVehicles();
        seedBusRoutes();
        seedIncidents();
    }

    private void seedJunctions() {
        if (junctionRepo.count() > 0) return;
        // 6 columns x 4 rows grid
        double[] lons = {-74.010, -74.006, -74.002, -73.998, -73.994, -73.990};
        double[] lats = {40.730, 40.724, 40.718, 40.712};
        String[] names = {
                "Northgate", "Oak Avenue", "Park Square", "Museum", "Eastgate", "Harbour View",
                "Civic Center", "Central Station", "City Hall", "Library", "Plaza", "Market Square",
                "University", "Technology Park", "Riverside", "City Hospital", "Stadium", "Arts District",
                "West Terminal", "Industrial Zone", "Southgate", "Depot", "Airport Link", "South Harbour"
        };
        int idx = 0;
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 6; c++) {
                String id = String.format("J-%02d", idx + 1);
                junctionRepo.save(new Junction(id, names[idx], lats[r], lons[c]));
                idx++;
            }
        }
    }

    private void seedRoads() {
        if (roadRepo.count() > 0) return;
        // Horizontal roads (20): within each row
        double[][] hCongestion = {
                {0.1, 0.3, 0.6, 0.2, 0.4}, // row 0
                {0.5, 0.7, 0.3, 0.2, 0.6}, // row 1
                {0.4, 0.8, 0.5, 0.3, 0.2}, // row 2
                {0.2, 0.6, 0.4, 0.3, 0.5}  // row 3
        };
        int roadIdx = 1;
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 5; c++) {
                String from = String.format("J-%02d", r * 6 + c + 1);
                String to = String.format("J-%02d", r * 6 + c + 2);
                double cong = hCongestion[r][c];
                roadRepo.save(new Road(String.format("R-%02d", roadIdx++), from, to,
                        0.5, 50, true, cong, "Corridor " + (r + 1) + " · Segment " + (c + 1)));
            }
        }
        // Vertical roads (18): within each column
        double[] vCongestion = {0.3, 0.5, 0.7, 0.4, 0.6, 0.3, 0.5, 0.8, 0.4, 0.3, 0.6, 0.5, 0.4, 0.7, 0.3, 0.2, 0.5, 0.6};
        int vIdx = 0;
        for (int c = 0; c < 6; c++) {
            for (int r = 0; r < 3; r++) {
                String from = String.format("J-%02d", r * 6 + c + 1);
                String to = String.format("J-%02d", (r + 1) * 6 + c + 1);
                roadRepo.save(new Road(String.format("R-%02d", roadIdx++), from, to,
                        0.7, 40, true, vCongestion[vIdx++], "Avenue " + (c + 1) + " · Link " + (r + 1)));
            }
        }
        // Diagonal roads (4)
        String[][] diagonals = {
                {"J-01", "J-08"}, {"J-08", "J-15"}, {"J-15", "J-22"}, {"J-09", "J-14"}
        };
        double[] dCongestion = {0.2, 0.4, 0.3, 0.5};
        for (int i = 0; i < diagonals.length; i++) {
            roadRepo.save(new Road(String.format("R-%02d", roadIdx++), diagonals[i][0], diagonals[i][1],
                    0.9, 60, true, dCongestion[i], "Diagonal Link " + (i + 1)));
        }
        // Close one road for routing demonstration
        Road closed = roadRepo.findById("R-19").orElseThrow();
        closed.setAvailable(false);
        roadRepo.save(closed);
    }

    private void seedVehicles() {
        if (vehicleRepo.count() > 0) return;
        String[] types = {"CAR", "BUS", "EMERGENCY", "TRUCK"};
        String[] junctions = {"J-01", "J-08", "J-14", "J-16", "J-22"};
        for (int i = 0; i < 8; i++) {
            vehicleRepo.save(new Vehicle(types[i % types.length], junctions[i % junctions.length]));
        }
    }

    private void seedBusRoutes() {
        if (routeRepo.count() > 0) return;
        // B-01 Central Station to University
        BusRoute b1 = new BusRoute("B-01", "Central Station to University", "#8DCBFA", RouteStatus.ON_TIME, 22);
        routeRepo.save(b1);
        addStops(b1.getId(), new String[][]{
                {"J-08", "Central Station"}, {"J-09", "City Hall"}, {"J-10", "Library"},
                {"J-16", "City Hospital"}, {"J-15", "Riverside"}, {"J-14", "Technology Park"},
                {"J-13", "University"}
        });

        // B-02 Civic Center to Riverside
        BusRoute b2 = new BusRoute("B-02", "Civic Center to Riverside", "#C7F36B", RouteStatus.ON_TIME, 14);
        routeRepo.save(b2);
        addStops(b2.getId(), new String[][]{
                {"J-07", "Civic Center"}, {"J-08", "Central Station"},
                {"J-14", "Technology Park"}, {"J-15", "Riverside"}
        });

        // B-03 Technology Park to City Hospital
        BusRoute b3 = new BusRoute("B-03", "Technology Park to City Hospital", "#E8C46A", RouteStatus.DELAYED, 12);
        routeRepo.save(b3);
        addStops(b3.getId(), new String[][]{
                {"J-14", "Technology Park"}, {"J-08", "Central Station"},
                {"J-09", "City Hall"}, {"J-10", "Library"}, {"J-16", "City Hospital"}
        });

        // B-04 North Terminal to Market Square
        BusRoute b4 = new BusRoute("B-04", "North Terminal to Market Square", "#F09A64", RouteStatus.ON_TIME, 18);
        routeRepo.save(b4);
        addStops(b4.getId(), new String[][]{
                {"J-01", "North Terminal"}, {"J-07", "Civic Center"}, {"J-08", "Central Station"},
                {"J-09", "City Hall"}, {"J-10", "Library"}, {"J-11", "Plaza"}, {"J-12", "Market Square"}
        });
    }

    private void addStops(String routeId, String[][] stops) {
        for (int i = 0; i < stops.length; i++) {
            stopRepo.save(new BusStop(routeId, stops[i][0], stops[i][1], i));
        }
    }

    private void seedIncidents() {
        if (incidentRepo.count() > 0) return;
        incidentRepo.save(new Incident("INC-001", IncidentType.ROAD_ACCIDENT, "J-04",
                Severity.HIGH, "Collision reported near Museum junction.",
                LocalDateTime.now().minusMinutes(15), IncidentStatus.IN_PROGRESS, "Unit A-12"));
        incidentRepo.save(new Incident("INC-002", IncidentType.HEAVY_CONGESTION, "J-12",
                Severity.MEDIUM, "Build-up of traffic approaching Market Square.",
                LocalDateTime.now().minusMinutes(42), IncidentStatus.REPORTED, null));
        incidentRepo.save(new Incident("INC-003", IncidentType.VEHICLE_BREAKDOWN, "J-20",
                Severity.LOW, "Broken-down vehicle on Industrial Zone link.",
                LocalDateTime.now().minusMinutes(8), IncidentStatus.REPORTED, null));
    }
}
