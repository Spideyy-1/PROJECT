package com.smartcity.model.enums;

/** Lifecycle status of an incident. */
public enum IncidentStatus {
    REPORTED,
    IN_PROGRESS,
    RESOLVED,
    CLOSED
}
