package com.smartcity.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * A road segment (graph edge) connecting two junctions.
 * <p>
 * Each road carries a distance (km), a speed limit (km/h), an availability
 * flag (closed roads are excluded from routing) and a congestion level in
 * the range [0.0, 1.0] used by the congestion-avoidance route mode.
 * </p>
 * <p>
 * Estimated travel time = distance / effective speed, where effective speed
 * is reduced by congestion: {@code speedLimit * (1 - congestionLevel)}.
 * </p>
 */
@Entity
@Table(name = "road")
public class Road {

    @Id
    private String id;

    private String startJunctionId;
    private String endJunctionId;

    private double distanceKm;
    private int speedLimitKmh;
    private boolean available = true;

    /** Congestion level in [0.0, 1.0]. 0 = free flow, 1 = fully congested. */
    private double congestionLevel;

    private String name;

    public Road() {
    }

    public Road(String id, String startJunctionId, String endJunctionId,
                double distanceKm, int speedLimitKmh, boolean available,
                double congestionLevel, String name) {
        setId(id);
        this.startJunctionId = startJunctionId;
        this.endJunctionId = endJunctionId;
        setDistanceKm(distanceKm);
        setSpeedLimitKmh(speedLimitKmh);
        this.available = available;
        setCongestionLevel(congestionLevel);
        this.name = name;
    }

    /** Estimated travel time in minutes. */
    public double estimatedTimeMinutes() {
        double effectiveSpeed = speedLimitKmh * (1.0 - congestionLevel);
        if (effectiveSpeed <= 0.1) {
            effectiveSpeed = 0.1;
        }
        return (distanceKm / effectiveSpeed) * 60.0;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Road id must not be blank");
        }
        this.id = id;
    }

    public String getStartJunctionId() {
        return startJunctionId;
    }

    public void setStartJunctionId(String startJunctionId) {
        this.startJunctionId = startJunctionId;
    }

    public String getEndJunctionId() {
        return endJunctionId;
    }

    public void setEndJunctionId(String endJunctionId) {
        this.endJunctionId = endJunctionId;
    }

    public double getDistanceKm() {
        return distanceKm;
    }

    public void setDistanceKm(double distanceKm) {
        if (distanceKm < 0) {
            throw new IllegalArgumentException("Distance must be non-negative");
        }
        this.distanceKm = distanceKm;
    }

    public int getSpeedLimitKmh() {
        return speedLimitKmh;
    }

    public void setSpeedLimitKmh(int speedLimitKmh) {
        if (speedLimitKmh <= 0) {
            throw new IllegalArgumentException("Speed limit must be positive");
        }
        this.speedLimitKmh = speedLimitKmh;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public double getCongestionLevel() {
        return congestionLevel;
    }

    public void setCongestionLevel(double congestionLevel) {
        if (congestionLevel < 0.0 || congestionLevel > 1.0) {
            throw new IllegalArgumentException("Congestion level must be in [0.0, 1.0]");
        }
        this.congestionLevel = congestionLevel;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Road{" + id + " " + startJunctionId + "->" + endJunctionId
                + " " + distanceKm + "km @" + speedLimitKmh + "km/h"
                + (available ? "" : " [CLOSED]") + "}";
    }
}
