package com.smartcity.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * A stop on a {@link BusRoute}. Stops are ordered by {@code sequence} and
 * reconstructed into a {@link com.smartcity.ds.LinkedList linked list} by the
 * transport service.
 */
@Entity
@Table(name = "bus_stop")
public class BusStop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String routeId;
    private String junctionId;
    private String name;
    private int sequence;

    public BusStop() {
    }

    public BusStop(String routeId, String junctionId, String name, int sequence) {
        this.routeId = routeId;
        this.junctionId = junctionId;
        this.name = name;
        this.sequence = sequence;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRouteId() {
        return routeId;
    }

    public void setRouteId(String routeId) {
        this.routeId = routeId;
    }

    public String getJunctionId() {
        return junctionId;
    }

    public void setJunctionId(String junctionId) {
        this.junctionId = junctionId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        if (sequence < 0) {
            throw new IllegalArgumentException("Sequence must be non-negative");
        }
        this.sequence = sequence;
    }
}
