package com.smartcity.algorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A weighted road graph using an <strong>adjacency list</strong>.
 * <p>
 * Vertices are junction IDs (Strings). Edges are {@link Edge} objects carrying
 * distance, estimated time, congestion and availability. Roads are undirected:
 * adding a road inserts an edge in both directions.
 * </p>
 * <p>
 * Closed roads ({@code available == false}) are still stored but are filtered
 * out during traversal/routing so they cannot be used.
 * </p>
 */
public class Graph {

    private final Map<String, List<Edge>> adjacency = new HashMap<>();
    private final Set<String> vertices = new HashSet<>();

    public void addVertex(String id) {
        vertices.add(id);
        adjacency.computeIfAbsent(id, k -> new ArrayList<>());
    }

    /**
     * Add an undirected road between two junctions.
     */
    public void addRoad(String from, String to, double distanceKm, double timeMinutes,
                        double congestionLevel, boolean available, String roadId) {
        addVertex(from);
        addVertex(to);
        adjacency.get(from).add(new Edge(from, to, distanceKm, timeMinutes, congestionLevel, available, roadId));
        adjacency.get(to).add(new Edge(to, from, distanceKm, timeMinutes, congestionLevel, available, roadId));
    }

    public Set<String> getVertices() {
        return Collections.unmodifiableSet(vertices);
    }

    /** Returns only available (non-closed) outgoing edges for a vertex. */
    public List<Edge> getNeighbors(String vertex) {
        List<Edge> all = adjacency.getOrDefault(vertex, Collections.emptyList());
        List<Edge> out = new ArrayList<>();
        for (Edge e : all) {
            if (e.isAvailable()) {
                out.add(e);
            }
        }
        return out;
    }

    public boolean containsVertex(String id) {
        return vertices.contains(id);
    }

    public int vertexCount() {
        return vertices.size();
    }

    public int edgeCount() {
        int total = 0;
        for (List<Edge> edges : adjacency.values()) {
            total += edges.size();
        }
        return total / 2; // undirected
    }
}
