package com.smartcity.service;

import com.smartcity.algorithm.Dijkstra;
import com.smartcity.algorithm.Graph;
import com.smartcity.algorithm.PathResult;
import com.smartcity.dto.RouteResponse;
import com.smartcity.model.Road;
import com.smartcity.model.enums.RouteMode;
import com.smartcity.repository.RoadRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.function.ToDoubleFunction;
import com.smartcity.algorithm.Edge;

/**
 * Route planning service. Builds a weighted {@link Graph} from the road
 * repository and delegates to {@link Dijkstra} for shortest-path computation.
 *
 * <p>Supports three modes via different edge-cost functions:</p>
 * <ul>
 *   <li>{@link RouteMode#DISTANCE} — cost = distance (km)</li>
 *   <li>{@link RouteMode#TIME} — cost = estimated time (min)</li>
 *   <li>{@link RouteMode#AVOID_CONGESTION} — cost = time * (1 + 3 * congestion)</li>
 * </ul>
 */
@Service
public class RouteService {

    private final RoadRepository roadRepository;

    public RouteService(RoadRepository roadRepository) {
        this.roadRepository = roadRepository;
    }

    /** Build the current road graph from all stored roads. */
    public Graph buildGraph() {
        Graph graph = new Graph();
        for (Road road : roadRepository.findAll()) {
            graph.addRoad(
                    road.getStartJunctionId(),
                    road.getEndJunctionId(),
                    road.getDistanceKm(),
                    road.estimatedTimeMinutes(),
                    road.getCongestionLevel(),
                    road.isAvailable(),
                    road.getId()
            );
        }
        return graph;
    }

    public RouteResponse calculateRoute(String source, String destination, RouteMode mode) {
        if (source == null || destination == null || source.isBlank() || destination.isBlank()) {
            throw new IllegalArgumentException("Source and destination must be provided");
        }
        if (source.equals(destination)) {
            return new RouteResponse(true, List.of(source), List.of(), 0, 0, mode.name(),
                    "Source and destination are the same junction.", List.of());
        }

        Graph graph = buildGraph();
        ToDoubleFunction<Edge> weight = switch (mode) {
            case DISTANCE -> Dijkstra.distanceWeight();
            case TIME -> Dijkstra.timeWeight();
            case AVOID_CONGESTION -> Dijkstra.congestionAvoidanceWeight();
        };

        PathResult result = Dijkstra.shortestPath(graph, source, destination, weight);

        if (!result.isReachable()) {
            return new RouteResponse(false, List.of(), List.of(), 0, 0, mode.name(),
                    "Destination is unreachable from the selected source (roads may be closed).", List.of());
        }

        String reason = switch (mode) {
            case DISTANCE -> "Shortest path by total distance (" + String.format("%.1f", result.getTotalDistanceKm()) + " km).";
            case TIME -> "Fastest path by estimated time (" + String.format("%.1f", result.getTotalTimeMinutes()) + " min), accounting for current congestion.";
            case AVOID_CONGESTION -> "Route chosen to avoid congested roads (cost = time × (1 + 3 × congestion)).";
        };

        // Build alternatives using the other two modes.
        List<RouteResponse.AlternativeRoute> alternatives = new ArrayList<>();
        for (RouteMode altMode : RouteMode.values()) {
            if (altMode == mode) {
                continue;
            }
            ToDoubleFunction<Edge> altWeight = switch (altMode) {
                case DISTANCE -> Dijkstra.distanceWeight();
                case TIME -> Dijkstra.timeWeight();
                case AVOID_CONGESTION -> Dijkstra.congestionAvoidanceWeight();
            };
            PathResult alt = Dijkstra.shortestPath(graph, source, destination, altWeight);
            if (alt.isReachable()) {
                alternatives.add(new RouteResponse.AlternativeRoute(
                        altMode.name(), alt.getJunctions(), alt.getTotalDistanceKm(), alt.getTotalTimeMinutes()));
            }
        }

        return new RouteResponse(true, result.getJunctions(), result.getRoadIds(),
                result.getTotalDistanceKm(), result.getTotalTimeMinutes(), mode.name(), reason, alternatives);
    }
}
