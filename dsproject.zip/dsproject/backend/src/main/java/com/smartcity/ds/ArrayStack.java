package com.smartcity.ds;

import java.util.NoSuchElementException;

/**
 * A simple array-backed LIFO stack. Used as a helper for iterative graph
 * traversals and expression/stack-based demos.
 */
public class ArrayStack<T> {

    private final Object[] stack;
    private int top;

    public ArrayStack(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be positive");
        }
        this.stack = new Object[capacity];
        this.top = -1;
    }

    public void push(T value) {
        if (top == stack.length - 1) {
            throw new IllegalStateException("Stack overflow");
        }
        stack[++top] = value;
    }

    @SuppressWarnings("unchecked")
    public T pop() {
        if (top < 0) {
            throw new NoSuchElementException("Stack underflow");
        }
        T v = (T) stack[top];
        stack[top--] = null;
        return v;
    }

    @SuppressWarnings("unchecked")
    public T peek() {
        if (top < 0) {
            throw new NoSuchElementException("Stack is empty");
        }
        return (T) stack[top];
    }

    public int size() {
        return top + 1;
    }

    public boolean isEmpty() {
        return top < 0;
    }
}
