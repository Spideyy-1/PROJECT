package com.smartcity.model;

import com.smartcity.model.enums.IncidentStatus;
import com.smartcity.model.enums.IncidentType;
import com.smartcity.model.enums.Severity;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

/**
 * A traffic/emergency incident.
 * <p>
 * Incidents are processed through a {@link com.smartcity.ds.MaxHeap max-heap}
 * priority queue ordered by severity (descending), with report time (ascending)
 * as the tie-breaker.
 * </p>
 * <p>
 * <strong>Disclaimer:</strong> this is an academic simulation and is not
 * connected to real emergency dispatch services.
 * </p>
 */
@Entity
@Table(name = "incident")
public class Incident {

    @Id
    private String id;

    @Enumerated(EnumType.STRING)
    private IncidentType type;

    private String junctionId;

    @Enumerated(EnumType.STRING)
    private Severity severity;

    private String description;

    private LocalDateTime reportedTime;

    @Enumerated(EnumType.STRING)
    private IncidentStatus status;

    private String assignedUnit;

    public Incident() {
    }

    public Incident(String id, IncidentType type, String junctionId, Severity severity,
                    String description, LocalDateTime reportedTime, IncidentStatus status,
                    String assignedUnit) {
        setId(id);
        this.type = type;
        this.junctionId = junctionId;
        this.severity = severity;
        this.description = description;
        this.reportedTime = reportedTime;
        this.status = status;
        this.assignedUnit = assignedUnit;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Incident id must not be blank");
        }
        this.id = id;
    }

    public IncidentType getType() {
        return type;
    }

    public void setType(IncidentType type) {
        this.type = type;
    }

    public String getJunctionId() {
        return junctionId;
    }

    public void setJunctionId(String junctionId) {
        this.junctionId = junctionId;
    }

    public Severity getSeverity() {
        return severity;
    }

    public void setSeverity(Severity severity) {
        this.severity = severity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getReportedTime() {
        return reportedTime;
    }

    public void setReportedTime(LocalDateTime reportedTime) {
        this.reportedTime = reportedTime;
    }

    public IncidentStatus getStatus() {
        return status;
    }

    public void setStatus(IncidentStatus status) {
        this.status = status;
    }

    public String getAssignedUnit() {
        return assignedUnit;
    }

    public void setAssignedUnit(String assignedUnit) {
        this.assignedUnit = assignedUnit;
    }

    @Override
    public String toString() {
        return "Incident{" + id + " " + type + " @ " + junctionId
                + " severity=" + severity + " status=" + status + "}";
    }
}
