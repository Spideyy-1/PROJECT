package com.smartcity.service;

import com.smartcity.model.Junction;
import com.smartcity.model.Road;
import com.smartcity.repository.JunctionRepository;
import com.smartcity.repository.RoadRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Traffic monitoring service. Derives junction-level congestion state,
 * density, average speed and network KPIs from the road dataset.
 */
@Service
public class TrafficService {

    private final JunctionRepository junctionRepository;
    private final RoadRepository roadRepository;

    public TrafficService(JunctionRepository junctionRepository, RoadRepository roadRepository) {
        this.junctionRepository = junctionRepository;
        this.roadRepository = roadRepository;
    }

    /**
     * Aggregate congestion level for a junction = average congestion of its
     * connected roads. Returns 0..1.
     */
    public double junctionCongestion(String junctionId) {
        List<Road> roads = connectedRoads(junctionId);
        if (roads.isEmpty()) {
            return 0.0;
        }
        double sum = 0;
        for (Road r : roads) {
            sum += r.getCongestionLevel();
        }
        return sum / roads.size();
    }

    /**
     * Effective average speed (km/h) at a junction = average of each connected
     * road's effective speed (speedLimit * (1 - congestion)).
     */
    public double junctionAverageSpeed(String junctionId) {
        List<Road> roads = connectedRoads(junctionId);
        if (roads.isEmpty()) {
            return 0.0;
        }
        double sum = 0;
        for (Road r : roads) {
            sum += r.getSpeedLimitKmh() * (1.0 - r.getCongestionLevel());
        }
        return sum / roads.size();
    }

    /** Estimated vehicle density 0..1 derived from congestion. */
    public double junctionDensity(String junctionId) {
        return Math.min(1.0, junctionCongestion(junctionId) * 1.1);
    }

    public List<Road> connectedRoads(String junctionId) {
        return roadRepository.findByStartJunctionIdOrEndJunctionId(junctionId, junctionId);
    }

    /** Traffic state label from congestion level. */
    public String trafficState(double congestion) {
        if (congestion < 0.25) return "FREE_FLOW";
        if (congestion < 0.5) return "LIGHT";
        if (congestion < 0.75) return "MODERATE";
        return "HEAVY";
    }

    /** Network-wide KPIs. */
    public Map<String, Object> getKpis() {
        List<Road> roads = roadRepository.findAll();
        List<Junction> junctions = junctionRepository.findAll();

        double avgSpeed = 0;
        int congestedJunctions = 0;
        for (Junction j : junctions) {
            avgSpeed += junctionAverageSpeed(j.getId());
            if (junctionCongestion(j.getId()) >= 0.5) {
                congestedJunctions++;
            }
        }
        avgSpeed = junctions.isEmpty() ? 0 : avgSpeed / junctions.size();

        int closedRoads = 0;
        for (Road r : roads) {
            if (!r.isAvailable()) closedRoads++;
        }

        Map<String, Object> kpis = new HashMap<>();
        kpis.put("averageSpeedKmh", Math.round(avgSpeed));
        kpis.put("congestedJunctions", congestedJunctions);
        kpis.put("totalJunctions", junctions.size());
        kpis.put("totalRoads", roads.size());
        kpis.put("closedRoads", closedRoads);
        kpis.put("simulated", true);
        return kpis;
    }

    /** Return status for every junction (for the traffic explorer). */
    public List<Map<String, Object>> allJunctionStatuses() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Junction j : junctionRepository.findAll()) {
            Map<String, Object> s = new HashMap<>();
            double congestion = junctionCongestion(j.getId());
            s.put("id", j.getId());
            s.put("name", j.getName());
            s.put("lat", j.getLat());
            s.put("lon", j.getLon());
            s.put("congestion", congestion);
            s.put("state", trafficState(congestion));
            s.put("averageSpeedKmh", Math.round(junctionAverageSpeed(j.getId())));
            s.put("density", junctionDensity(j.getId()));
            out.add(s);
        }
        return out;
    }
}
