package com.smartcity.dto;

import com.smartcity.model.enums.RouteStatus;

import java.util.List;

/**
 * A bus route with its ordered stops (sourced from a custom linked list).
 */
public record RouteWithStops(
        String id,
        String name,
        String color,
        RouteStatus status,
        int durationMinutes,
        List<String> stopNames,
        List<String> stopJunctionIds,
        int stopCount,
        String nextArrival
) {
}
