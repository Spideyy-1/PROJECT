package com.smartcity.repository;

import com.smartcity.model.BusStop;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BusStopRepository extends JpaRepository<BusStop, Long> {
    List<BusStop> findByRouteIdOrderBySequenceAsc(String routeId);
}
