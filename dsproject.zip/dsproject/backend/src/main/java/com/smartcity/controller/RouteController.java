package com.smartcity.controller;

import com.smartcity.dto.RouteRequest;
import com.smartcity.dto.RouteResponse;
import com.smartcity.service.RouteService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/routes")
public class RouteController {

    private final RouteService routeService;

    public RouteController(RouteService routeService) {
        this.routeService = routeService;
    }

    @PostMapping
    public RouteResponse calculate(@RequestBody RouteRequest request) {
        return routeService.calculateRoute(request.source(), request.destination(), request.mode());
    }
}
