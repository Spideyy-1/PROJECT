package com.smartcity.model.enums;

/**
 * Route optimization modes supported by the route engine.
 */
public enum RouteMode {
    /** Minimise total distance (km). */
    DISTANCE,
    /** Minimise estimated travel time (minutes), accounting for congestion. */
    TIME,
    /** Prefer clearer roads; cost = time * (1 + 3 * congestionLevel). */
    AVOID_CONGESTION
}
