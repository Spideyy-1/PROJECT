package com.smartcity.algorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.function.ToDoubleFunction;

/**
 * Dijkstra's shortest-path algorithm over the road {@link Graph}.
 * <p>
 * The edge cost is supplied as a {@link ToDoubleFunction} so the same
 * implementation supports multiple optimization modes:
 * <ul>
 *   <li><b>Shortest Distance</b> — cost = edge distance (km).</li>
 *   <li><b>Fastest Estimated Time</b> — cost = edge estimated time (min).</li>
 *   <li><b>Avoid Congestion</b> — cost = time * (1 + 3 * congestionLevel).
 *       This heavily penalises congested edges so the engine prefers clearer
 *       roads even when they are slightly longer in pure time.</li>
 * </ul>
 * Closed (unavailable) roads are excluded by {@link Graph#getNeighbors}.
 * </p>
 */
public final class Dijkstra {

    private Dijkstra() {
    }

    /** Cost function: shortest distance. */
    public static ToDoubleFunction<Edge> distanceWeight() {
        return Edge::getDistanceKm;
    }

    /** Cost function: fastest estimated time. */
    public static ToDoubleFunction<Edge> timeWeight() {
        return Edge::getTimeMinutes;
    }

    /**
     * Cost function: avoid congestion.
     * Formula: {@code timeMinutes * (1 + 3 * congestionLevel)}.
     * A fully congested edge (congestionLevel = 1.0) costs 4x its time,
     * strongly encouraging the engine to route around it.
     */
    public static ToDoubleFunction<Edge> congestionAvoidanceWeight() {
        return e -> e.getTimeMinutes() * (1.0 + 3.0 * e.getCongestionLevel());
    }

    /**
     * Compute the lowest-cost path from {@code source} to {@code dest}.
     *
     * @return a {@link PathResult}; if the destination is unreachable the
     *         result has {@code reachable == false} and empty junction/road
     *         lists.
     */
    public static PathResult shortestPath(Graph graph, String source, String dest,
                                          ToDoubleFunction<Edge> weight) {
        if (!graph.containsVertex(source) || !graph.containsVertex(dest)) {
            return new PathResult(Collections.emptyList(), Collections.emptyList(), 0, 0, false);
        }

        Map<String, Double> dist = new HashMap<>();
        Map<String, String> prevJunction = new HashMap<>();
        Map<String, String> prevRoad = new HashMap<>();
        Set<String> settled = new HashSet<>();

        for (String v : graph.getVertices()) {
            dist.put(v, Double.POSITIVE_INFINITY);
        }
        dist.put(source, 0.0);

        PriorityQueue<String> pq = new PriorityQueue<>((a, b) -> Double.compare(dist.get(a), dist.get(b)));
        pq.add(source);

        while (!pq.isEmpty()) {
            String u = pq.poll();
            if (settled.contains(u)) {
                continue;
            }
            settled.add(u);
            if (u.equals(dest)) {
                break;
            }
            for (Edge e : graph.getNeighbors(u)) {
                String v = e.getTo();
                if (settled.contains(v)) {
                    continue;
                }
                double alt = dist.get(u) + weight.applyAsDouble(e);
                if (alt < dist.get(v)) {
                    dist.put(v, alt);
                    prevJunction.put(v, u);
                    prevRoad.put(v, e.getRoadId());
                    pq.add(v);
                }
            }
        }

        if (Double.isInfinite(dist.get(dest))) {
            return new PathResult(Collections.emptyList(), Collections.emptyList(), 0, 0, false);
        }

        // Reconstruct path
        List<String> junctions = new ArrayList<>();
        List<String> roadIds = new ArrayList<>();
        String cur = dest;
        junctions.add(cur);
        while (!cur.equals(source)) {
            String road = prevRoad.get(cur);
            if (road != null) {
                roadIds.add(road);
            }
            cur = prevJunction.get(cur);
            junctions.add(cur);
        }
        Collections.reverse(junctions);
        Collections.reverse(roadIds);

        // Recompute actual distance and time along the chosen path by looking
        // up each used road in the graph adjacency.
        double totalDistance = 0;
        double totalTime = 0;
        Map<String, Edge> edgeByRoadId = new HashMap<>();
        for (String v : graph.getVertices()) {
            for (Edge e : graph.getNeighbors(v)) {
                edgeByRoadId.putIfAbsent(e.getRoadId(), e);
            }
        }
        for (String roadId : roadIds) {
            Edge e = edgeByRoadId.get(roadId);
            if (e != null) {
                totalDistance += e.getDistanceKm();
                totalTime += e.getTimeMinutes();
            }
        }

        return new PathResult(junctions, roadIds, totalDistance, totalTime, true);
    }
}
