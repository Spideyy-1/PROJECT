package com.smartcity.service;

import com.smartcity.model.Incident;
import com.smartcity.model.Junction;
import com.smartcity.model.Road;
import com.smartcity.model.enums.IncidentType;
import com.smartcity.model.enums.Severity;
import com.smartcity.repository.IncidentRepository;
import com.smartcity.repository.JunctionRepository;
import com.smartcity.repository.RoadRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Analytics service. Computes traffic, incident and transport statistics from
 * the stored dataset using sorting and frequency counting.
 *
 * <p>Method note: all numbers are derived from the application's sample
 * traffic, road, incident and transport records — they are not real
 * city-wide statistics.</p>
 */
@Service
public class AnalyticsService {

    private final RoadRepository roadRepository;
    private final JunctionRepository junctionRepository;
    private final IncidentRepository incidentRepository;
    private final TrafficService trafficService;

    public AnalyticsService(RoadRepository roadRepository,
                            JunctionRepository junctionRepository,
                            IncidentRepository incidentRepository,
                            TrafficService trafficService) {
        this.roadRepository = roadRepository;
        this.junctionRepository = junctionRepository;
        this.incidentRepository = incidentRepository;
        this.trafficService = trafficService;
    }

    /** Distribution of roads by congestion bucket (free/light/moderate/heavy). */
    public Map<String, Integer> congestionDistribution() {
        Map<String, Integer> dist = new LinkedHashMap<>();
        dist.put("Free flow", 0);
        dist.put("Light", 0);
        dist.put("Moderate", 0);
        dist.put("Heavy", 0);
        for (Road r : roadRepository.findAll()) {
            String bucket = trafficService.trafficState(r.getCongestionLevel());
            switch (bucket) {
                case "FREE_FLOW" -> dist.merge("Free flow", 1, Integer::sum);
                case "LIGHT" -> dist.merge("Light", 1, Integer::sum);
                case "MODERATE" -> dist.merge("Moderate", 1, Integer::sum);
                default -> dist.merge("Heavy", 1, Integer::sum);
            }
        }
        return dist;
    }

    /** Average effective speed per road. */
    public List<Map<String, Object>> averageSpeedByRoad() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Road r : roadRepository.findAll()) {
            Map<String, Object> m = new HashMap<>();
            m.put("roadId", r.getId());
            m.put("name", r.getName());
            m.put("speedLimit", r.getSpeedLimitKmh());
            m.put("effectiveSpeed", Math.round(r.getSpeedLimitKmh() * (1.0 - r.getCongestionLevel())));
            out.add(m);
        }
        out.sort(Comparator.comparing(m -> (String) m.get("roadId")));
        return out;
    }

    /** Incident count by type (frequency counting). */
    public Map<String, Integer> incidentsByType() {
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (IncidentType t : IncidentType.values()) {
            counts.put(t.name(), 0);
        }
        for (Incident i : incidentRepository.findAll()) {
            counts.merge(i.getType().name(), 1, Integer::sum);
        }
        return counts;
    }

    /** Incident count by severity. */
    public Map<String, Integer> incidentsBySeverity() {
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (Severity s : Severity.values()) {
            counts.put(s.name(), 0);
        }
        for (Incident i : incidentRepository.findAll()) {
            counts.merge(i.getSeverity().name(), 1, Integer::sum);
        }
        return counts;
    }

    /** Junctions sorted by descending congestion (most congested first). */
    public List<Map<String, Object>> mostCongestedJunctions(int limit) {
        List<Map<String, Object>> list = new ArrayList<>();
        for (Junction j : junctionRepository.findAll()) {
            Map<String, Object> m = new HashMap<>();
            m.put("id", j.getId());
            m.put("name", j.getName());
            m.put("congestion", trafficService.junctionCongestion(j.getId()));
            list.add(m);
        }
        list.sort(Comparator.comparingDouble(m -> -((Double) m.get("congestion"))));
        if (list.size() > limit) {
            return list.subList(0, limit);
        }
        return list;
    }

    /** Road utilisation = count of roads by availability + congestion level. */
    public Map<String, Object> roadUtilization() {
        List<Road> roads = roadRepository.findAll();
        int open = 0, closed = 0;
        double avgCongestion = 0;
        for (Road r : roads) {
            if (r.isAvailable()) open++; else closed++;
            avgCongestion += r.getCongestionLevel();
        }
        avgCongestion = roads.isEmpty() ? 0 : avgCongestion / roads.size();
        Map<String, Object> out = new HashMap<>();
        out.put("total", roads.size());
        out.put("open", open);
        out.put("closed", closed);
        out.put("averageCongestion", avgCongestion);
        return out;
    }

    /**
     * Incidents over time — grouped by severity for the last N "hours"
     * (simulated buckets derived from reported time modulo).
     */
    public Map<String, Object> incidentsOverTime() {
        List<Incident> incidents = incidentRepository.findAll();
        // Group by hour-of-day bucket (simulated)
        Map<Integer, Map<String, Integer>> byHour = new LinkedHashMap<>();
        for (int h = 0; h < 24; h += 4) {
            Map<String, Integer> sev = new LinkedHashMap<>();
            for (Severity s : Severity.values()) {
                sev.put(s.name(), 0);
            }
            byHour.put(h, sev);
        }
        for (Incident i : incidents) {
            int hour = i.getReportedTime().getHour();
            int bucket = (hour / 4) * 4;
            byHour.get(bucket).merge(i.getSeverity().name(), 1, Integer::sum);
        }
        Map<String, Object> out = new HashMap<>();
        out.put("buckets", byHour.keySet().stream().toList());
        out.put("series", byHour);
        return out;
    }

    /**
     * Distance-vs-time comparison: for a fixed set of sample source/destination
     * pairs, compare shortest distance vs fastest time totals.
     */
    public Map<String, Object> distanceVsTime(RouteService routeService) {
        List<String[]> pairs = List.of(
                new String[]{"J-01", "J-24"},
                new String[]{"J-01", "J-12"},
                new String[]{"J-07", "J-18"},
                new String[]{"J-19", "J-06"}
        );
        List<Map<String, Object>> rows = new ArrayList<>();
        for (String[] p : pairs) {
            var dist = routeService.calculateRoute(p[0], p[1], com.smartcity.model.enums.RouteMode.DISTANCE);
            var time = routeService.calculateRoute(p[0], p[1], com.smartcity.model.enums.RouteMode.TIME);
            Map<String, Object> row = new HashMap<>();
            row.put("from", p[0]);
            row.put("to", p[1]);
            row.put("shortestDistanceKm", dist.totalDistanceKm());
            row.put("fastestTimeMin", time.totalTimeMinutes());
            row.put("fastestDistanceKm", time.totalDistanceKm());
            rows.add(row);
        }
        Map<String, Object> out = new HashMap<>();
        out.put("comparisons", rows);
        return out;
    }
}
