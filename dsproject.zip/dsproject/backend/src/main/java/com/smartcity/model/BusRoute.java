package com.smartcity.model;

import com.smartcity.model.enums.RouteStatus;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * A public-transport (bus) route. Stops are stored as separate
 * {@link BusStop} rows ordered by sequence; the service layer reconstructs
 * them into an explicitly implemented {@link com.smartcity.ds.LinkedList}.
 */
@Entity
@Table(name = "bus_route")
public class BusRoute {

    @Id
    private String id;

    private String name;
    private String color;

    @Enumerated(EnumType.STRING)
    private RouteStatus status;

    private int durationMinutes;

    public BusRoute() {
    }

    public BusRoute(String id, String name, String color, RouteStatus status, int durationMinutes) {
        setId(id);
        this.name = name;
        this.color = color;
        this.status = status;
        this.durationMinutes = durationMinutes;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Bus route id must not be blank");
        }
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public RouteStatus getStatus() {
        return status;
    }

    public void setStatus(RouteStatus status) {
        this.status = status;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public void setDurationMinutes(int durationMinutes) {
        this.durationMinutes = durationMinutes;
    }
}
