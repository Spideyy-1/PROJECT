package com.smartcity.service;

import com.smartcity.ds.LinkedList;
import com.smartcity.dto.RouteWithStops;
import com.smartcity.model.BusRoute;
import com.smartcity.model.BusStop;
import com.smartcity.repository.BusRouteRepository;
import com.smartcity.repository.BusStopRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Public transport service.
 *
 * <p>Bus stops for each route are reconstructed into an explicitly implemented
 * {@link LinkedList} (ordered by sequence) to demonstrate the linked-list data
 * structure. Next-arrival times follow a deterministic simulation rule:</p>
 *
 * <pre>
 *   arrival = baseTime + (routeIndex * offsetMinutes) % headway
 *   baseTime = current minute rounded down to the headway boundary
 * </pre>
 *
 * <p>This produces stable, reproducible arrivals rather than arbitrary
 * changing text.</p>
 */
@Service
public class TransportService {

    private static final int HEADWAY_MINUTES = 15; // buses every 15 minutes
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");

    private final BusRouteRepository routeRepository;
    private final BusStopRepository stopRepository;

    public TransportService(BusRouteRepository routeRepository, BusStopRepository stopRepository) {
        this.routeRepository = routeRepository;
        this.stopRepository = stopRepository;
    }

    public List<BusRoute> findAllRoutes() {
        return routeRepository.findAll();
    }

    public Optional<BusRoute> findRoute(String id) {
        return routeRepository.findById(id);
    }

    /**
     * Return stops for a route as a custom linked list (ordered by sequence).
     */
    public LinkedList<BusStop> stopsAsLinkedList(String routeId) {
        List<BusStop> dbStops = stopRepository.findByRouteIdOrderBySequenceAsc(routeId);
        LinkedList<BusStop> list = new LinkedList<>();
        for (BusStop s : dbStops) {
            list.add(s);
        }
        return list;
    }

    public RouteWithStops routeWithStops(String routeId) {
        Optional<BusRoute> routeOpt = routeRepository.findById(routeId);
        if (routeOpt.isEmpty()) {
            return null;
        }
        BusRoute route = routeOpt.get();
        LinkedList<BusStop> stops = stopsAsLinkedList(routeId);
        List<String> names = new ArrayList<>();
        List<String> junctionIds = new ArrayList<>();
        for (BusStop s : stops) {
            names.add(s.getName());
            junctionIds.add(s.getJunctionId());
        }
        return new RouteWithStops(
                route.getId(),
                route.getName(),
                route.getColor(),
                route.getStatus(),
                route.getDurationMinutes(),
                names,
                junctionIds,
                stops.size(),
                nextArrival(routeId)
        );
    }

    public List<RouteWithStops> allRoutesWithStops() {
        List<RouteWithStops> out = new ArrayList<>();
        for (BusRoute r : routeRepository.findAll()) {
            out.add(routeWithStops(r.getId()));
        }
        return out;
    }

    /**
     * Deterministic next-arrival simulation.
     * <p>
     * Buses run every {@value #HEADWAY_MINUTES} minutes. Each route has a fixed
     * offset (route index * 3 minutes) within the headway window. The next
     * arrival is the next boundary + offset that is strictly after now.
     * </p>
     */
    public String nextArrival(String routeId) {
        int routeIndex = Math.abs(routeId.hashCode()) % HEADWAY_MINUTES;
        LocalDateTime now = LocalDateTime.now();
        int minuteOfDay = now.getHour() * 60 + now.getMinute();
        int windowStart = (minuteOfDay / HEADWAY_MINUTES) * HEADWAY_MINUTES;
        int arrival = windowStart + routeIndex;
        if (arrival <= minuteOfDay) {
            arrival += HEADWAY_MINUTES;
        }
        arrival = arrival % (24 * 60);
        LocalDateTime arr = now.withHour(arrival / 60).withMinute(arrival % 60).withSecond(0).withNano(0);
        return arr.format(TIME_FMT);
    }
}
