package com.smartcity.repository;

import com.smartcity.model.Junction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JunctionRepository extends JpaRepository<Junction, String> {
}
