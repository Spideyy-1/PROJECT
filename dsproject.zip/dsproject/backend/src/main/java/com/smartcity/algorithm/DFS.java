package com.smartcity.algorithm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Depth-First Search traversal (recursive) over the road {@link Graph}.
 * Demonstrates recursive traversal; an iterative stack-based version lives in
 * {@link BFS#dfsIterative(Graph, String)}.
 */
public final class DFS {

    private DFS() {
    }

    /**
     * Recursive DFS from {@code start}, returning visit order.
     */
    public static List<String> traverse(Graph graph, String start) {
        List<String> order = new ArrayList<>();
        if (!graph.containsVertex(start)) {
            return order;
        }
        Set<String> visited = new HashSet<>();
        dfsRecursive(graph, start, visited, order);
        return order;
    }

    private static void dfsRecursive(Graph graph, String u, Set<String> visited, List<String> order) {
        visited.add(u);
        order.add(u);
        for (Edge e : graph.getNeighbors(u)) {
            if (!visited.contains(e.getTo())) {
                dfsRecursive(graph, e.getTo(), visited, order);
            }
        }
    }
}
