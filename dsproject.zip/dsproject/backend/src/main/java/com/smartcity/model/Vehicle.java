package com.smartcity.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * A vehicle currently reported on the network. Demonstrates a simple
 * persistable domain object.
 */
@Entity
@Table(name = "vehicle")
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String type;
    private String currentJunctionId;

    public Vehicle() {
    }

    public Vehicle(String type, String currentJunctionId) {
        this.type = type;
        this.currentJunctionId = currentJunctionId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrentJunctionId() {
        return currentJunctionId;
    }

    public void setCurrentJunctionId(String currentJunctionId) {
        this.currentJunctionId = currentJunctionId;
    }
}
