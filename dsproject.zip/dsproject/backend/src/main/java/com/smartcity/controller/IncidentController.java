package com.smartcity.controller;

import com.smartcity.algorithm.PathResult;
import com.smartcity.model.Incident;
import com.smartcity.model.enums.IncidentStatus;
import com.smartcity.model.enums.IncidentType;
import com.smartcity.model.enums.Severity;
import com.smartcity.service.IncidentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/incidents")
public class IncidentController {

    private final IncidentService incidentService;

    public IncidentController(IncidentService incidentService) {
        this.incidentService = incidentService;
    }

    @GetMapping
    public List<Incident> getAll(@RequestParam(required = false) IncidentType type,
                                 @RequestParam(required = false) Severity severity,
                                 @RequestParam(required = false) IncidentStatus status) {
        return incidentService.filter(type, severity, status);
    }

    @GetMapping("/priority")
    public List<Incident> priorityOrder() {
        return incidentService.priorityOrder();
    }

    @GetMapping("/active")
    public List<Incident> active() {
        return incidentService.activeIncidents();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Incident> getById(@PathVariable String id) {
        return incidentService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Incident create(@RequestBody Incident incident) {
        return incidentService.save(incident);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Incident> update(@PathVariable String id, @RequestBody Incident incident) {
        if (incidentService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        incident.setId(id);
        return ResponseEntity.ok(incidentService.save(incident));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Incident> updateStatus(@PathVariable String id, @RequestParam IncidentStatus status) {
        return incidentService.findById(id).map(inc -> {
            inc.setStatus(status);
            return ResponseEntity.ok(incidentService.save(inc));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        if (incidentService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        incidentService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/emergency-route")
    public ResponseEntity<PathResult> emergencyRoute(@PathVariable String id) {
        PathResult result = incidentService.emergencyRoute(id);
        if (result == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(result);
    }
}
