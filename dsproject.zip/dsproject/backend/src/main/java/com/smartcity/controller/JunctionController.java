package com.smartcity.controller;

import com.smartcity.model.Junction;
import com.smartcity.repository.JunctionRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/junctions")
public class JunctionController {

    private final JunctionRepository repository;

    public JunctionController(JunctionRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Junction> getAll() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Junction> getById(@PathVariable String id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Junction create(@RequestBody Junction junction) {
        return repository.save(junction);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Junction> update(@PathVariable String id, @RequestBody Junction junction) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        junction.setId(id);
        return ResponseEntity.ok(repository.save(junction));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
