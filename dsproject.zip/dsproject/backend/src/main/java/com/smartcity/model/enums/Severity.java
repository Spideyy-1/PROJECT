package com.smartcity.model.enums;

/**
 * Severity levels for incidents. Higher ordinal = higher priority.
 * Used by the {@link com.smartcity.ds.MaxHeap max-heap} priority queue.
 */
public enum Severity {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL;

    public int priority() {
        return ordinal();
    }
}
