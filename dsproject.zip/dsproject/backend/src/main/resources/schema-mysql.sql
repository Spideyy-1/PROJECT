-- SMART CITY — Traffic & Public Transport Management System
-- MySQL schema (for use with --spring.profiles.active=mysql)
-- The H2 default profile uses the same JPA entity mappings.

CREATE DATABASE IF NOT EXISTS smartcity;
USE smartcity;

CREATE TABLE IF NOT EXISTS junction (
    id VARCHAR(16) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    lat DOUBLE NOT NULL,
    lon DOUBLE NOT NULL
);

CREATE TABLE IF NOT EXISTS road (
    id VARCHAR(16) PRIMARY KEY,
    start_junction_id VARCHAR(16) NOT NULL,
    end_junction_id VARCHAR(16) NOT NULL,
    distance_km DOUBLE NOT NULL,
    speed_limit_kmh INT NOT NULL,
    available BOOLEAN NOT NULL DEFAULT TRUE,
    congestion_level DOUBLE NOT NULL DEFAULT 0.0,
    name VARCHAR(120)
);

CREATE TABLE IF NOT EXISTS vehicle (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(40) NOT NULL,
    current_junction_id VARCHAR(16)
);

CREATE TABLE IF NOT EXISTS bus_route (
    id VARCHAR(16) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    color VARCHAR(16),
    status VARCHAR(40),
    duration_minutes INT
);

CREATE TABLE IF NOT EXISTS bus_stop (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    route_id VARCHAR(16) NOT NULL,
    junction_id VARCHAR(16) NOT NULL,
    name VARCHAR(120) NOT NULL,
    sequence INT NOT NULL
);

CREATE TABLE IF NOT EXISTS incident (
    id VARCHAR(24) PRIMARY KEY,
    type VARCHAR(60) NOT NULL,
    junction_id VARCHAR(16),
    severity VARCHAR(20) NOT NULL,
    description VARCHAR(500),
    reported_time DATETIME NOT NULL,
    status VARCHAR(40) NOT NULL,
    assigned_unit VARCHAR(80)
);
