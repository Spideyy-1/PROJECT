package com.smartcity;

import com.smartcity.ds.ArrayStack;
import com.smartcity.ds.CircularQueue;
import com.smartcity.ds.LinkedList;
import com.smartcity.ds.MaxHeap;
import org.junit.jupiter.api.Test;

import java.util.Comparator;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

/** Tests for custom data structures. */
class DataStructuresTest {

    @Test
    void linkedListPreservesOrder() {
        LinkedList<String> list = new LinkedList<>();
        list.add("first");
        list.add("second");
        list.add("third");
        assertEquals(3, list.size());
        assertEquals("first", list.first());
        assertEquals("third", list.last());
        assertEquals("second", list.get(1));
        assertEquals(java.util.List.of("first", "second", "third"), list.toList());
    }

    @Test
    void maxHeapOrdersByComparator() {
        // Max-heap of integers (natural ordering = largest first)
        MaxHeap<Integer> heap = new MaxHeap<>(10, Comparator.naturalOrder());
        heap.add(3);
        heap.add(1);
        heap.add(4);
        heap.add(1);
        heap.add(5);
        assertEquals(5, heap.poll());
        assertEquals(4, heap.poll());
        assertEquals(3, heap.poll());
    }

    @Test
    void maxHeapCustomComparator() {
        // Simulate incident priority: severity desc (here value), then id asc
        record Item(int severity, String id) {}
        // For a max-heap, comparingInt(severity) makes higher severity "greater",
        // so it is polled first. Tie-break: earlier id first -> reverse id comparison.
        Comparator<Item> cmp = Comparator.comparingInt(Item::severity)
                .thenComparing(Comparator.comparing(Item::id).reversed());
        MaxHeap<Item> heap = new MaxHeap<>(10, cmp);
        heap.add(new Item(2, "b"));
        heap.add(new Item(1, "a"));
        heap.add(new Item(2, "a"));
        assertEquals(new Item(2, "a"), heap.poll()); // severity 2, earlier id
        assertEquals(new Item(2, "b"), heap.poll());
        assertEquals(new Item(1, "a"), heap.poll());
    }

    @Test
    void circularQueueFifo() {
        CircularQueue<Integer> q = new CircularQueue<>(5);
        q.enqueue(1);
        q.enqueue(2);
        q.enqueue(3);
        assertEquals(1, q.dequeue());
        assertEquals(2, q.peek());
        q.enqueue(4);
        assertEquals(2, q.dequeue());
        assertEquals(3, q.dequeue());
        assertEquals(4, q.dequeue());
        assertTrue(q.isEmpty());
    }

    @Test
    void arrayStackLifo() {
        ArrayStack<Integer> s = new ArrayStack<>(5);
        s.push(1);
        s.push(2);
        s.push(3);
        assertEquals(3, s.pop());
        assertEquals(2, s.peek());
        assertEquals(2, s.pop());
        assertEquals(1, s.pop());
        assertThrows(NoSuchElementException.class, s::pop);
    }
}
