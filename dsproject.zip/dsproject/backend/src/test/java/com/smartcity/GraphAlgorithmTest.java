package com.smartcity;

import com.smartcity.algorithm.BFS;
import com.smartcity.algorithm.DFS;
import com.smartcity.algorithm.Dijkstra;
import com.smartcity.algorithm.Graph;
import com.smartcity.algorithm.PathResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for graph algorithms: Dijkstra (distance & time), BFS, DFS.
 *
 * <p>Test graph (A-B-C-D linear plus a shortcut A-C):
 * <pre>
 *   A --2--> B --3--> C --1--> D
 *   |                 ^
 *   +--------6--------+
 * </pre>
 */
class GraphAlgorithmTest {

    private Graph buildGraph() {
        Graph g = new Graph();
        g.addRoad("A", "B", 2.0, 4.0, 0.0, true, "R1");   // 2km, 4min
        g.addRoad("B", "C", 3.0, 6.0, 0.0, true, "R2");   // 3km, 6min
        g.addRoad("C", "D", 1.0, 2.0, 0.0, true, "R3");   // 1km, 2min
        g.addRoad("A", "C", 6.0, 3.0, 0.0, true, "R4");   // 6km, 3min (shortcut, slower distance but faster time)
        return g;
    }

    @Test
    void dijkstraShortestDistance() {
        Graph g = buildGraph();
        PathResult r = Dijkstra.shortestPath(g, "A", "D", Dijkstra.distanceWeight());
        assertTrue(r.isReachable());
        // Shortest distance: A-B-C-D = 2+3+1 = 6 (NOT A-C-D = 6+1 = 7)
        assertEquals(6.0, r.getTotalDistanceKm(), 0.001);
        assertEquals(List.of("A", "B", "C", "D"), r.getJunctions());
    }

    @Test
    void dijkstraFastestTime() {
        Graph g = buildGraph();
        PathResult r = Dijkstra.shortestPath(g, "A", "D", Dijkstra.timeWeight());
        assertTrue(r.isReachable());
        // Fastest time: A-C-D = 3+2 = 5 min (vs A-B-C-D = 4+6+2 = 12 min)
        assertEquals(5.0, r.getTotalTimeMinutes(), 0.001);
        assertEquals(List.of("A", "C", "D"), r.getJunctions());
    }

    @Test
    void dijkstraUnreachableWhenRoadClosed() {
        Graph g = new Graph();
        g.addRoad("A", "B", 1.0, 2.0, 0.0, true, "R1");
        g.addRoad("B", "C", 1.0, 2.0, 0.0, false, "R2"); // closed
        PathResult r = Dijkstra.shortestPath(g, "A", "C", Dijkstra.distanceWeight());
        assertFalse(r.isReachable());
    }

    @Test
    void bfsOrder() {
        Graph g = buildGraph();
        List<String> order = BFS.traverse(g, "A");
        assertEquals("A", order.get(0));
        // BFS from A visits B and C (neighbors) before D
        assertTrue(order.indexOf("B") < order.indexOf("D"));
        assertTrue(order.indexOf("C") < order.indexOf("D"));
    }

    @Test
    void dfsOrder() {
        Graph g = buildGraph();
        List<String> order = DFS.traverse(g, "A");
        assertEquals("A", order.get(0));
        assertEquals(4, order.size());
        assertTrue(order.containsAll(List.of("A", "B", "C", "D")));
    }

    @Test
    void connectedComponents() {
        Graph g = new Graph();
        g.addRoad("A", "B", 1.0, 2.0, 0.0, true, "R1");
        g.addRoad("C", "D", 1.0, 2.0, 0.0, true, "R2"); // separate component
        List<List<String>> comps = BFS.connectedComponents(g);
        assertEquals(2, comps.size());
    }
}
