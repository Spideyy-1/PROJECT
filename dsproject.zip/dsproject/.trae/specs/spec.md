# SMART CITY — Traffic & Public Transport Management System - Product Requirements Document

## Overview
- **Summary**: An educational web application that models an urban road network as a weighted graph and provides traffic monitoring, Dijkstra-based route planning, public-transport tracking, incident prioritization, and analytics. It combines a polished editorial landing page with an interactive operations dashboard.
- **Purpose**: Demonstrate Java OOP and data-structure/algorithm concepts (graphs, Dijkstra, BFS/DFS, priority queue/heap, linked list, queue, stack, hashing, sorting) through a traffic & public-transport management system, with a REST backend and a responsive frontend.
- **Target Users**: Students/reviewers evaluating data-structure/OOP demonstration; operators interacting with the dashboard.

## Goals
- Represent the road network as a graph (adjacency list) of junctions (vertices) and roads (weighted edges).
- Calculate shortest-distance and fastest-estimated-time routes via Dijkstra; explore connectivity via BFS/DFS.
- Simulate congestion, road closures, and changing road conditions affecting route cost.
- Manage incidents through an explicit max-heap priority queue (severity first, report-time tie-breaker).
- Track public transport routes with an explicitly implemented ordered linked list of stops and simulated arrivals.
- Compute analytics (congestion distribution, incidents by type, most congested junctions, route distance vs time) using sorting and frequency counting.
- Deliver a premium dark editorial landing page and a fully interactive dashboard with a coherent shared dataset.
- Backend persists records (H2 with MySQL-compatible mode by default; MySQL schema + config provided) and exposes REST APIs; frontend consumes them and can also run stand-alone with its own real algorithms over the same sample graph.

## Non-Goals
- Real-time live traffic/GPS integration or connection to official city infrastructure or emergency dispatch.
- User authentication/authorization beyond a simple operator role concept (no production security).
- Mobile native apps.
- Production deployment hardening, multi-tenant data isolation, or real payment/billing.

## Background & Context
- Reference for visual inspiration (typography/layout only): techsum.digital — original work, no copied text/assets.
- Environment: Java 23 present; no system Maven/Node/MySQL. Maven will be downloaded. Frontend uses vanilla HTML/CSS/JS with Chart.js + Leaflet via CDN (no build step). Persistence defaults to H2 in-memory (MySQL-compatible) with a MySQL schema provided.

## Functional Requirements
- **FR-1 Road network model**: Junctions (id, name, lat/lon) and roads (start, end, distance, speedLimit, available, congestion level) stored and retrievable via REST.
- **FR-2 Graph algorithms**: Backend implements Dijkstra (distance and estimated-time weights), BFS, DFS, and connectivity/components over the road graph; closed roads excluded.
- **FR-3 Route planning**: Route request validates endpoints, supports modes Shortest Distance / Fastest Estimated Time / Avoid Congestion (documented congestion-adjusted cost), returns ordered junctions, total distance, estimated time, highlighted path, alternatives when available, and handles closed/unreachable.
- **FR-4 Traffic monitoring**: Junction-level congestion state, density, average speed, connected roads; derived KPIs (average speed, congested junctions).
- **FR-5 Incident management**: CRUD incidents (id, type, location, severity Low/Medium/High/Critical, description, reportedTime, status, assignedUnit); priority queue (max-heap) by severity then report time; sort/filter by type/severity/status; sample emergency route.
- **FR-6 Public transport**: Bus routes (B-01..B-04) with stops stored in an explicitly implemented linked list; search/filter; simulated next arrival by a defined rule; route highlighting on map.
- **FR-7 Analytics**: Charts — congestion distribution, avg speed by road, incidents by type, bus service distribution, most congested junctions, road utilization, incidents over time, distance-vs-time; time/metric/entity filters; empty states.
- **FR-8 Road network management**: Add/edit/delete/view junctions and road segments in the dashboard.
- **FR-9 Landing page**: All sections (Hero, System Overview 7 capabilities, Dashboard Preview, Route Planner, Public Transport, Incident Management, Analytics, Architecture, Capability Showcase, Philosophy, Sample Metrics, FAQ, Final CTA + Footer) rendered with the specified visual system.
- **FR-10 Dashboard views**: /dashboard, /traffic, /routes, /transport, /incidents, /analytics, /road-network (as tabs/views within the SPA) — all functional, no empty placeholders.
- **FR-11 Data coherence**: One coherent dataset across map, KPIs, events, routes, incidents, transit, analytics; values labeled simulated.
- **FR-12 Accessibility/UX**: Semantic HTML, keyboard navigation, focus states, responsive breakpoints, working mobile menu, accordions, tooltips, empty/error states.
- **FR-13 OOP demonstration**: Java classes for Junction, Road, Vehicle, BusRoute, BusStop, Incident, Graph, RouteEngine, IncidentPriorityQueue, etc. with encapsulation, inheritance, interfaces, polymorphism, exceptions, resource management.
- **FR-14 Tests**: JUnit tests for graph algorithms (Dijkstra, BFS, DFS), priority queue, and key services.

## Non-Functional Requirements
- **NFR-1**: Backend starts and serves REST APIs on http://localhost:8080.
- **NFR-2**: Frontend opens as static files (or served) and is fully interactive; CDN libraries load.
- **NFR-3**: Coherent dataset shared between backend seed data and frontend sample data (same junction/road/bus/incident ids and structure).
- **NFR-4**: All simulated/non-production values explicitly labeled.
- **NFR-5**: Code organized by layer (controller/service/repository/model/algorithm).

## Constraints
- **Technical**: Java 23, Spring Boot 3.x, Maven (downloaded), H2 (MySQL-compatible) default + MySQL schema provided; frontend vanilla HTML/CSS/JS, Chart.js, Leaflet via CDN.
- **Business**: Academic demonstration only; no real data claims.
- **Dependencies**: Internet for Maven downloads and CDN libraries at runtime.

## Assumptions
- A local browser can open the frontend static files.
- Maven can be downloaded to the workspace.
- H2 in-memory is acceptable for runnable persistence; MySQL schema provided for switching.
- The dashboard can run standalone (frontend algorithms) when the backend is not reachable.

## Open Questions
- None blocking; defaults chosen above.

## Acceptance Criteria

### AC-1: Backend builds and runs
- **Type**: `rule`
- **Given**: Maven available and project structure in place
- **When**: `mvn spring-boot:run` is executed
- **Then**: The application starts on port 8080 without errors and REST endpoints respond
- **Pass Condition**: HTTP 200 from `/api/junctions` (or similar health/data endpoint)
- **Evidence**: Terminal log showing started application; curl/HTTP response

### AC-2: Road network graph model & APIs
- **Type**: `rule`
- **Given**: Seeded road network
- **When**: GET `/api/junctions`, `/api/roads`, `/api/graph`
- **Then**: Returns junctions (>=10), roads (>=15), and graph adjacency structure
- **Pass Condition**: JSON arrays of correct size with required fields
- **Evidence**: API response payload

### AC-3: Dijkstra shortest distance route
- **Type**: `rule`
- **Given**: A connected sample graph with weighted roads
- **When**: POST `/api/routes` with source, destination, mode=DISTANCE
- **Then**: Returns a valid ordered path, total distance, and estimated time; closed roads excluded
- **Pass Condition**: Path endpoints match source/destination; distance equals sum of road distances; no closed road in path
- **Evidence**: API response + JUnit test pass

### AC-4: Fastest-time & congestion-avoidance modes
- **Type**: `rule`
- **Given**: Roads with speed limits and congestion multipliers
- **When**: Route requested with mode=TIME and mode=AVOID_CONGESTION
- **Then**: Time mode minimizes estimated time; congestion mode adjusts cost by congestion and availability (documented formula)
- **Pass Condition**: Different inputs produce different (non-hardcoded) routes; formula documented in code/docs
- **Evidence**: API responses for multiple input pairs

### AC-5: BFS/DFS connectivity
- **Type**: `rule`
- **Given**: The road graph
- **When**: GET `/api/graph/bfs?start=...` and `/api/graph/dfs?start=...`
- **Then**: Returns traversal order and connected components
- **Pass Condition**: BFS order is breadth-first; DFS is depth-first; components correct
- **Evidence**: API response + JUnit test

### AC-6: Incident priority queue (max-heap)
- **Type**: `rule`
- **Given**: Multiple incidents of varying severity and report times
- **When**: Incidents are added and the priority queue is polled
- **Then**: Highest severity returned first; ties broken by earliest report time
- **Pass Condition**: Poll order matches severity-desc then time-asc
- **Evidence**: JUnit test output + API `/api/incidents/priority`

### AC-7: Incident CRUD & filtering
- **Type**: `rule`
- **Given**: Incident repository
- **When**: POST/PUT/GET/DELETE incidents with filters (type, severity, status)
- **Then**: Records persist and filter correctly; status changes work
- **Pass Condition**: Filtered list contains only matching incidents; deleted incident gone
- **Evidence**: API responses

### AC-8: Public transport with linked-list stops
- **Type**: `rule`
- **Given**: Bus routes B-01..B-04
- **When**: GET `/api/transport/routes` and `/api/transport/routes/{id}/stops`
- **Then**: Stops returned in order from an explicitly implemented linked list; next arrival computed by a fixed simulation rule
- **Pass Condition**: Stop order is deterministic and matches route definition; arrival rule documented
- **Evidence**: API response + source showing custom LinkedList class

### AC-9: Analytics computation
- **Type**: `rule`
- **Given**: Seeded traffic/incident/transport data
- **When**: GET `/api/analytics/*` endpoints
- **Then**: Returns congestion distribution, incidents by type, most congested junctions, avg speed by road, incidents over time, distance-vs-time, bus distribution
- **Pass Condition**: Numbers derived from dataset (not hardcoded arrays); sum of frequency counts matches totals
- **Evidence**: API response payloads

### AC-10: Landing page sections present & styled
- **Type**: `rubric`
- **Dimension**: Completeness and visual fidelity of landing page against the brief
- **Scale**: 1-5
- **Anchors**: 1 = missing many sections / generic look; 3 = most sections present, basic dark styling; 5 = all 13 sections, premium editorial dark aesthetic, specified palette/typography, responsive
- **Pass Threshold**: >= 4
- **Evidence**: Browser screenshot of landing page

### AC-11: Dashboard interactivity
- **Type**: `rule`
- **Given**: Dashboard loaded
- **When**: User clicks junctions, switches tabs (traffic/routes/transport/incidents/analytics/road-network), applies filters, submits route form, creates incident, refreshes
- **Then**: UI updates correctly (details panel, map layers, KPIs, charts, event list) without console errors
- **Pass Condition**: Each interaction produces expected state change; no uncaught exceptions
- **Evidence**: Browser interaction log/screenshots

### AC-12: Dataset coherence & simulation labels
- **Type**: `rule`
- **Given**: The running app
- **When**: Reviewing KPIs, map, incidents, buses
- **Then**: Same junction/road/incident/bus IDs appear consistently; simulated/non-production labels present where values are shown
- **Pass Condition**: KPIs derived from dataset (e.g., active incidents count equals incidents with status!=RESOLVED)
- **Evidence**: Cross-check of IDs across views

### AC-13: OOP & data-structure demonstration
- **Type**: `rubric`
- **Dimension**: Breadth and visibility of OOP/data-structure concepts in Java code
- **Scale**: 1-5
- **Anchors**: 1 = few classes, no custom DS; 3 = graph + Dijkstra + basic OOP; 5 = graph+Dijkstra+BFS/DFS+max-heap priority queue+custom linked list+queue+stack+hashing/sorting+inheritance/interfaces/polymorphism/exceptions all present and used meaningfully
- **Pass Threshold**: >= 4
- **Evidence**: Source code structure inspection

### AC-14: JUnit tests pass
- **Type**: `rule`
- **Given**: Test sources present
- **When**: `mvn test` run
- **Then**: Algorithm/service tests pass
- **Pass Condition**: All tests green
- **Evidence**: Maven test output

### AC-15: Responsive & accessible
- **Type**: `rubric`
- **Dimension**: Responsiveness and accessibility
- **Scale**: 1-5
- **Anchors**: 1 = broken on mobile, no keyboard support; 3 = usable desktop, some mobile issues; 5 = works on mobile/desktop, keyboard nav, focus states, semantic HTML, mobile menu works
- **Pass Threshold**: >= 4
- **Evidence**: Mobile-width screenshots + keyboard test
