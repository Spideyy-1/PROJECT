# SMART CITY — Traffic & Public Transport Management System - Implementation Plan

## Task 1: Environment setup & Spring Boot skeleton
- **Status**: `pending`
- **Priority**: high
- **Depends On**: None
- **Description**:
  - Download Apache Maven to the workspace and verify `mvn` works.
  - Create Spring Boot Maven project: `pom.xml` (Spring Boot 3.x, web, data-jpa, h2, validation, test), `src/main/resources/application.properties` (H2 MySQL-compatible mode, server port 8080), `SmartCityApplication.java` main class.
  - Create MySQL schema script `schema-mysql.sql` and `application-mysql.properties` for switching.
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `rule` TR-1.1: `mvn -v` prints Maven version after download
  - `rule` TR-1.2: `mvn compile` succeeds for the empty app
- **Notes**: Use a fixed Maven version (3.9.9).

## Task 2: Domain entities & repositories
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 1
- **Description**:
  - JPA entities: `Junction` (id, name, lat, lon), `Road` (id, startJunctionId, endJunctionId, distanceKm, speedLimitKmh, available, congestionLevel 0-1), `Vehicle` (id, type, currentJunctionId), `BusRoute` (id, name, color, status), `BusStop` (id, routeId, junctionId, name, sequence), `Incident` (id, type, junctionId, severity enum, description, reportedTime, status, assignedUnit).
  - Enums: `Severity` (LOW,MEDIUM,HIGH,CRITICAL), `IncidentStatus`, `IncidentType`.
  - Spring Data JPA repositories for each.
  - OOP: encapsulation (private fields, getters/setters with validation), constructors.
- **Acceptance Criteria Addressed**: AC-2, AC-13
- **Test Requirements**:
  - `rule` TR-2.1: Entities map to H2 tables (compile + app starts with ddl-auto)
  - `rule` TR-2.2: Repository beans load without error at startup

## Task 3: Data structure & algorithm engine
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 2
- **Description**:
  - `Graph` class with adjacency list of weighted edges (using a custom or built-in structure).
  - `Dijkstra` shortest path by distance and by estimated time; supports excluded (closed) edges.
  - `BFS` and `DFS` traversals + connected components.
  - `MaxHeap`-based `IncidentPriorityQueue` (severity desc, reportTime asc tie-break).
  - Custom `LinkedList<T>` for ordered stops.
  - `ArrayQueue`/`CircularQueue` for event queue, `ArrayStack` for traversal helpers.
  - Hashing (HashMap) for junction lookups; sorting (Collections.sort / custom) for analytics.
  - Document congestion-avoidance cost formula in code.
- **Acceptance Criteria Addressed**: AC-3, AC-4, AC-5, AC-6, AC-13
- **Test Requirements**:
  - `rule` TR-3.1: Dijkstra returns correct shortest distance on a known graph (JUnit)
  - `rule` TR-3.2: Dijkstra time mode differs from distance mode where congestion differs
  - `rule` TR-3.3: BFS order is breadth-first; DFS is depth-first (JUnit)
  - `rule` TR-3.4: Priority queue orders by severity desc then time asc (JUnit)
  - `rule` TR-3.5: LinkedList preserves insertion order and supports iteration

## Task 4: Services & seed data
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 3
- **Description**:
  - `RouteService`: builds graph from roads, delegates to Dijkstra for DISTANCE/TIME/AVOID_CONGESTION modes, alternatives, unreachable handling.
  - `TrafficService`: junction congestion state, density, avg speed, KPIs.
  - `IncidentService`: CRUD, priority queue ordering, filters, emergency route sample.
  - `TransportService`: routes with linked-list stops, simulated next-arrival rule (fixed interval + offset, documented).
  - `AnalyticsService`: congestion distribution, incidents by type, most congested junctions, avg speed by road, incidents over time, distance-vs-time, bus distribution.
  - Seed data: 24 junctions, 42 roads, 4 bus routes with stops, 3 incidents, vehicles.
- **Acceptance Criteria Addressed**: AC-2, AC-7, AC-8, AC-9, AC-12
- **Test Requirements**:
  - `rule` TR-4.1: RouteService returns non-null path for connected endpoints
  - `rule` TR-4.2: Analytics counts sum to dataset totals
  - `rule` TR-4.3: Transport next-arrival is deterministic given seed time

## Task 5: REST controllers
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 4
- **Description**:
  - Controllers: `JunctionController`, `RoadController`, `RouteController`, `TrafficController`, `IncidentController`, `TransportController`, `AnalyticsController`, `GraphController`.
  - Endpoints match FR list; return JSON; handle not-found/unreachable with appropriate HTTP status + messages.
  - CORS enabled for frontend origin.
- **Acceptance Criteria Addressed**: AC-1, AC-2, AC-7, AC-8, AC-9
- **Test Requirements**:
  - `rule` TR-5.1: GET /api/junctions returns >=10 items
  - `rule` TR-5.2: GET /api/roads returns >=15 items
  - `rule` TR-5.3: POST /api/routes returns valid route for a valid pair
  - `rule` TR-5.4: GET /api/incidents/priority returns severity-ordered list

## Task 6: JUnit tests
- **Status**: `pending`
- **Priority**: medium
- **Depends On**: Task 5
- **Description**:
  - Tests for Dijkstra (distance/time), BFS, DFS, priority queue, linked list, analytics counts, route service.
  - Run with `mvn test`.
- **Acceptance Criteria Addressed**: AC-3, AC-5, AC-6, AC-14
- **Test Requirements**:
  - `rule` TR-6.1: `mvn test` exits with code 0 and all tests pass

## Task 7: Backend build & run verification
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 6
- **Description**:
  - Run `mvn spring-boot:run`, verify startup, hit key endpoints with curl.
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `rule` TR-7.1: App starts and GET /api/junctions returns 200 with JSON

## Task 8: Frontend skeleton & shared assets
- **Status**: `pending`
- **Priority**: high
- **Depends On**: None
- **Description**:
  - `frontend/index.html` (landing), `frontend/dashboard.html` (SPA).
  - `frontend/css/style.css` with the specified palette, typography (Inter via CDN), spacing, responsive breakpoints.
  - `frontend/js/data.js` shared sample dataset mirroring backend seed (same IDs/values).
  - `frontend/js/api.js` REST client with graceful fallback to local dataset when backend unreachable.
- **Acceptance Criteria Addressed**: AC-10, AC-11, AC-12
- **Test Requirements**:
  - `rule` TR-8.1: CSS defines all palette colors as variables
  - `rule` TR-8.2: data.js contains 24 junctions, 42 roads, 4 routes, 3 incidents

## Task 9: Frontend data structures & algorithms
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 8
- **Description**:
  - JS implementations: `Graph` (adjacency list), `Dijkstra` (distance/time/congestion modes), `BFS`, `DFS`, `MaxHeap` priority queue, `LinkedList`, `Queue`, `Stack`.
  - Use these in the dashboard so it works without the backend.
- **Acceptance Criteria Addressed**: AC-3, AC-4, AC-5, AC-6, AC-13
- **Test Requirements**:
  - `rule` TR-9.1: JS Dijkstra returns correct path for a known pair (verified via browser console or test)
  - `rule` TR-9.2: Priority queue orders correctly

## Task 10: Landing page (all 13 sections)
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 8
- **Description**:
  - Implement Hero, System Overview (7 capabilities), Dashboard Preview, Route Planner, Public Transport, Incident Management, Analytics, Architecture, Capability Showcase, Philosophy, Sample Metrics, FAQ accordion, Final CTA + Footer.
  - SMART CITY wordmark + connected-road symbol (original SVG).
  - Smooth nav, mobile menu, scroll state.
- **Acceptance Criteria Addressed**: AC-10, AC-15
- **Test Requirements**:
  - `rule` TR-10.1: All 13 sections present in DOM
  - `rubric` TR-10.2: Visual fidelity; scale 1-5; anchors per AC-10; threshold >=4; evidence: screenshot

## Task 11: Dashboard shell & map
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 8, Task 9
- **Description**:
  - Dashboard top bar (network state, simulated time, last update, notifications, operator menu), sidebar (Overview, Live Traffic, Route Planner, Public Transport, Incidents, Road Network, Analytics, Settings), KPI strip.
  - Leaflet map with >=10 junctions, >=15 roads, congestion coloring, incident markers, bus lines, legend, zoom/recenter/layer filters (All Roads, Congestion, Incidents, Bus Routes).
  - View routing via tabs (hash-based) for all 7 views.
- **Acceptance Criteria Addressed**: AC-11, AC-12
- **Test Requirements**:
  - `rule` TR-11.1: Map renders with junction markers and roads
  - `rule` TR-11.2: Layer filters toggle visible layers
  - `rule` TR-11.3: Sidebar switches active view

## Task 12: Traffic view
- **Status**: `pending`
- **Priority**: medium
- **Depends On**: Task 11
- **Description**:
  - Junction explorer list with congestion filters; click junction -> details panel (traffic state, density, avg speed, connected roads, nearby incidents).
- **Acceptance Criteria Addressed**: AC-4, AC-11, AC-12
- **Test Requirements**:
  - `rule` TR-12.1: Selecting a junction updates details panel with correct data

## Task 13: Routes view
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 11, Task 9
- **Description**:
  - Source/destination selects, optimization mode (Shortest/Fastest/Avoid Congestion), avoidance toggles.
  - On submit: run Dijkstra, show ordered junctions, total distance, estimated time, highlighted map route, selection reason, alternatives.
  - Handle closed roads and unreachable destinations.
- **Acceptance Criteria Addressed**: AC-3, AC-4, AC-11
- **Test Requirements**:
  - `rule` TR-13.1: Submitting a valid pair shows a route with distance/time
  - `rule` TR-13.2: Changing mode changes the result where applicable
  - `rule` TR-13.3: Unreachable endpoints show an error state

## Task 14: Public Transport view
- **Status**: `pending`
- **Priority**: medium
- **Depends On**: Task 11, Task 9
- **Description**:
  - Route directory (B-01..B-04) with ID, name, stops, status, duration, next arrival, color.
  - Search/filter by route or stop; selecting route highlights on map; stop list expand/collapse.
  - Arrivals from deterministic simulation rule.
- **Acceptance Criteria Addressed**: AC-8, AC-11
- **Test Requirements**:
  - `rule` TR-14.1: Selecting a route highlights it on the map
  - `rule` TR-14.2: Search filters the route list

## Task 15: Incidents view
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 11, Task 9
- **Description**:
  - Create/edit incident form (type, location, severity, description).
  - List with sort by severity/time, filter by type/severity/status, status change/resolve, location on map, emergency route sample.
  - Priority ordering via max-heap.
- **Acceptance Criteria Addressed**: AC-6, AC-7, AC-11
- **Test Requirements**:
  - `rule` TR-15.1: Creating an incident adds it to the list and map
  - `rule` TR-15.2: Sorting by severity orders Critical first
  - `rule` TR-15.3: Resolving an incident changes its status

## Task 16: Analytics view
- **Status**: `pending`
- **Priority**: medium
- **Depends On**: Task 11
- **Description**:
  - Chart.js charts: congestion distribution, avg speed by road, incidents by type, bus service distribution, most congested junctions, road utilization, incidents over time, distance-vs-time.
  - Time/metric/entity selectors; empty states; accessible labels.
- **Acceptance Criteria Addressed**: AC-9, AC-11
- **Test Requirements**:
  - `rule` TR-16.1: All 8 charts render with data from the dataset

## Task 17: Road Network view
- **Status**: `pending`
- **Priority**: medium
- **Depends On**: Task 11
- **Description**:
  - Tables for junctions and roads; add/edit/delete forms; connection visualization.
- **Acceptance Criteria Addressed**: AC-2, AC-11
- **Test Requirements**:
  - `rule` TR-17.1: Adding a junction appears in the list and map

## Task 18: Integration, responsive polish & accessibility
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 10–Task 17
- **Description**:
  - Wire landing-page dashboard preview CTA to dashboard.
  - Ensure mobile menu, keyboard nav, focus states, accordions, tooltips.
  - Label all simulated/hypothetical values.
  - Final cross-browser/console-error check.
- **Acceptance Criteria Addressed**: AC-11, AC-12, AC-15
- **Test Requirements**:
  - `rule` TR-18.1: No uncaught console errors on dashboard interactions
  - `rubric` TR-18.2: Responsive/accessibility; scale 1-5 per AC-15; threshold >=4; evidence: mobile screenshot + keyboard test
