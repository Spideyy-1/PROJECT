/* SMART CITY — Landing page interactions */
(function () {
  const $ = id => document.getElementById(id);

  /* ---------- Helpers ---------- */
  const jpos = (() => {
    const m = {};
    DATA.junctions.forEach(j => m[j.id] = j);
    return m;
  })();
  function gx(jid) {
    const c = jid.replace("J-","") * 1;
    const col = (c - 1) % 6, row = Math.floor((c - 1) / 6);
    return { x: 40 + col * 55, y: 40 + row * 85 };
  }
  function congColor(c) {
    if (c < 0.25) return "#75D6A0";
    if (c < 0.5) return "#E8C46A";
    if (c < 0.75) return "#F09A64";
    return "#F16F6F";
  }
  const stateLabel = s => s.split("_").map(w => w[0] + w.slice(1).toLowerCase()).join(" ");

  /* ---------- Hero network SVG ---------- */
  function drawHeroNet() {
    const svg = $("heroNet");
    let html = "";
    DATA.roads.forEach(r => {
      if (!r.available) return;
      const a = gx(r.startJunctionId), b = gx(r.endJunctionId);
      html += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#343A34" stroke-width="2"/>`;
    });
    DATA.junctions.forEach(j => {
      const p = gx(j.id);
      const c = API.junctionCongestion(j.id);
      html += `<circle cx="${p.x}" cy="${p.y}" r="5" fill="${congColor(c)}" stroke="#101110" stroke-width="2"/>`;
    });
    // Highlight a sample route J-01 -> J-08 -> J-15
    const route = [["J-01","J-08"],["J-08","J-15"]];
    route.forEach(([f,t]) => {
      const a = gx(f), b = gx(t);
      html += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#8DCBFA" stroke-width="3"/>`;
    });
    // Incident marker
    const ip = gx("J-04");
    html += `<rect x="${ip.x-4}" y="${ip.y-20}" width="8" height="10" fill="#F16F6F"/>`;
    svg.innerHTML = html;
  }

  /* ---------- Capabilities list ---------- */
  const CAPS = [
    { n:"01", t:"Traffic Monitoring", d:"Junction-level congestion, density and incident reporting.", tags:["Junction Monitoring","Density","Incident Status"], diag:"◉◉◉ CONGESTION" },
    { n:"02", t:"Intelligent Route Planning", d:"Weighted roads, shortest paths and distance/time comparison.", tags:["Graph Algorithms","Dijkstra","Route Comparison"], diag:"A → B → C" },
    { n:"03", t:"Public Transport Tracking", d:"Bus routes, stops, simulated arrivals and corridor connections.", tags:["Bus Routes","Stops","ETA Simulation"], diag:"B-01 ▸ ▸ ▸" },
    { n:"04", t:"Emergency Response", d:"Incidents, critical-event priority and sample emergency routes.", tags:["Priority Queue","Incident Management"], diag:"MAX-HEAP" },
    { n:"05", t:"Road Network Management", d:"Junctions, road segments, closures, speed limits and conditions.", tags:["Road Graph","Junctions","Closures"], diag:"GRAPH · 42" },
    { n:"06", t:"Mobility Analytics", d:"Congestion, incident frequency, journey estimates and performance.", tags:["Metrics","Sorting","Frequency"], diag:"▂▄▆█" },
    { n:"07", t:"Operations & Administration", d:"Maintain records and review operational changes.", tags:["Data Management","Validation","Audit"], diag:"CRUD" }
  ];
  function renderCaps() {
    $("capList").innerHTML = CAPS.map(c => `
      <div class="cap-item">
        <div class="cap-num">${c.n}</div>
        <div class="cap-body">
          <h3>${c.t}</h3>
          <p>${c.d}</p>
          <div class="cap-tags">${c.tags.map(t => `<span class="tag">${t}</span>`).join("")}</div>
        </div>
        <div class="cap-diagram">${c.diag}</div>
      </div>`).join("");
  }

  /* ---------- Dashboard preview KPIs & map ---------- */
  async function renderDashPreview() {
    const kpis = await API.getKpis();
    const incs = await API.getIncidents();
    const routes = await API.getBusRoutes();
    const kpiData = [
      { v: kpis.averageSpeedKmh, u:"km/h", l:"Avg Speed" },
      { v: kpis.congestedJunctions, u:"", l:"Congested Junctions" },
      { v: incs.filter(i => i.status !== "RESOLVED").length, u:"", l:"Active Incidents" },
      { v: routes.length * 4.5 | 0, u:"", l:"Active Buses (sim)" }
    ];
    $("dpKpis").innerHTML = kpiData.map(k => `
      <div class="dp-kpi"><div class="v">${k.v}${k.u ? " <span style='font-size:14px;color:var(--muted)'>"+k.u+"</span>" : ""}</div><div class="l">${k.l}</div></div>`).join("");

    const svg = $("dpMap");
    let h = "";
    DATA.roads.forEach(r => {
      if (!r.available) return;
      const a = gx(r.startJunctionId), b = gx(r.endJunctionId);
      h += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#343A34" stroke-width="2"/>`;
    });
    DATA.junctions.forEach(j => {
      const p = gx(j.id);
      const c = API.junctionCongestion(j.id);
      h += `<circle cx="${p.x}" cy="${p.y}" r="4" fill="${congColor(c)}"/>`;
    });
    // bus route B-01 highlight
    const b01 = DATA.busRoutes.find(r => r.id === "B-01");
    for (let i = 0; i < b01.stops.length - 1; i++) {
      const a = gx(b01.stops[i].junctionId), b = gx(b01.stops[i+1].junctionId);
      h += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#8DCBFA" stroke-width="3"/>`;
    }
    // incident marker
    const inc = incs[0];
    if (inc) {
      const ip = gx(inc.junctionId);
      h += `<rect x="${ip.x-5}" y="${ip.y-16}" width="10" height="8" fill="#F16F6F"/>`;
    }
    svg.innerHTML = h;

    const now = new Date();
    $("dpTime").textContent = now.toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" }) + " · SIMULATED";
  }

  /* ---------- Route Planner ---------- */
  function fillRouteSelects() {
    const opts = DATA.junctions.map(j => `<option value="${j.id}">${j.id} — ${j.name}</option>`).join("");
    $("rpSource").innerHTML = opts;
    $("rpDest").innerHTML = opts;
    $("rpSource").value = "J-01";
    $("rpDest").value = "J-24";
  }
  async function calcRoute() {
    const s = $("rpSource").value, d = $("rpDest").value, m = $("rpMode").value;
    const r = await API.calculateRoute(s, d, m);
    const stateColor = c => congColor(c);
    if (!r.reachable) {
      $("rpResult").innerHTML = `<h3>Route Unavailable</h3><p style="color:var(--critical);margin-top:8px;">${r.reason}</p>`;
      return;
    }
    const path = r.junctions.map(jid => {
      const j = jpos[jid];
      return `<span title="${j ? j.name : ""}">${jid}</span>`;
    }).join(" → ");
    const alts = (r.alternatives || []).map(a => `
      <div class="detail-row"><span class="k">${a.mode}</span><span>${a.totalDistanceKm.toFixed(1)} km · ${a.totalTimeMinutes.toFixed(1)} min</span></div>`).join("");
    $("rpResult").innerHTML = `
      <p class="mono muted" style="margin-bottom:12px;">${r.reason}</p>
      <div class="rp-metrics">
        <div class="m"><div class="v">${r.totalDistanceKm.toFixed(1)}</div><div class="l">Distance (km)</div></div>
        <div class="m"><div class="v">${r.totalTimeMinutes.toFixed(1)}</div><div class="l">Est. Time (min)</div></div>
        <div class="m"><div class="v">${r.junctions.length}</div><div class="l">Junctions</div></div>
      </div>
      <div class="rp-path">${path}</div>
      ${alts ? `<div style="margin-top:24px;padding-top:20px;border-top:1px solid var(--border);"><h4 style="margin-bottom:12px;">Alternatives</h4>${alts}</div>` : ""}
    `;
  }

  /* ---------- Public Transport ---------- */
  async function renderTransport() {
    const routes = await API.getBusRoutes();
    $("transportGrid").innerHTML = routes.map(r => `
      <div class="route-card" data-route="${r.id}">
        <div class="rhead"><span class="rid" style="color:${r.color}">${r.id}</span><span class="badge ${r.status==='ON_TIME'?'b-low':'b-medium'}">${r.status.replace("_"," ")}</span></div>
        <div class="rname">${r.name}</div>
        <div class="rmeta">
          <span>${r.stopCount} stops</span>
          <span>${r.durationMinutes} min</span>
          <span>Next: ${r.nextArrival}</span>
        </div>
        <div class="route-stops">${r.stopNames.map((s,i) => `<div style="padding:4px 0">${i+1}. ${s}</div>`).join("")}</div>
      </div>`).join("");
    document.querySelectorAll(".route-card").forEach(card => {
      card.addEventListener("click", () => card.classList.toggle("expanded"));
    });
  }

  /* ---------- Incidents table ---------- */
  async function renderIncidents() {
    const incs = await API.getPriorityIncidents();
    const sevBadge = s => `b-${s.toLowerCase()}`;
    const typeLabel = t => t.split("_").map(w => w[0]+w.slice(1).toLowerCase()).join(" ");
    $("incTable").querySelector("tbody").innerHTML = incs.map((i, idx) => `
      <tr>
        <td class="mono">${idx + 1}</td>
        <td class="mono">${i.id}</td>
        <td>${typeLabel(i.type)}</td>
        <td>${i.junctionId}${jpos[i.junctionId] ? " — " + jpos[i.junctionId].name : ""}</td>
        <td><span class="badge ${sevBadge(i.severity)}">${i.severity}</span></td>
        <td>${stateLabel(i.status)}</td>
        <td class="mono muted">${new Date(i.reportedTime).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</td>
      </tr>`).join("");
  }

  /* ---------- Analytics charts ---------- */
  Chart.defaults.color = "#A4AAA1";
  Chart.defaults.borderColor = "#343A34";
  async function renderCharts() {
    const cong = await API.getAnalytics("congestion-distribution");
    new Chart($("chCong"), {
      type: "doughnut",
      data: { labels: Object.keys(cong), datasets: [{ data: Object.values(cong), backgroundColor: ["#75D6A0","#E8C46A","#F09A64","#F16F6F"], borderWidth: 0 }] },
      options: { plugins: { legend: { position: "bottom" } } }
    });
    const incT = await API.getAnalytics("incidents-by-type");
    new Chart($("chIncType"), {
      type: "bar",
      data: { labels: Object.keys(incT).map(t => t.split("_").map(w=>w[0]).join("")), datasets: [{ label:"Incidents", data: Object.values(incT), backgroundColor: "#C7F36B" }] },
      options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
    });
    const spd = (await API.getAnalytics("speed-by-road")).slice(0, 12);
    new Chart($("chSpeed"), {
      type: "bar",
      data: { labels: spd.map(r => r.roadId), datasets: [
        { label:"Limit", data: spd.map(r => r.speedLimit), backgroundColor: "#343A34" },
        { label:"Effective", data: spd.map(r => r.effectiveSpeed), backgroundColor: "#8DCBFA" }
      ]},
      options: { plugins: { legend: { position: "bottom" } } }
    });
    const junc = await API.getAnalytics("most-congested-junctions");
    new Chart($("chJunc"), {
      type: "bar",
      data: { labels: junc.map(j => j.id), datasets: [{ label:"Congestion", data: junc.map(j => +j.congestion.toFixed(2)), backgroundColor: junc.map(j => congColor(j.congestion)) }] },
      options: { indexAxis: "y", plugins: { legend: { display: false } }, scales: { x: { max: 1 } } }
    });
  }

  /* ---------- Showcase SVGs ---------- */
  function drawShowcase() {
    const r = $("scRoad");
    let h = "";
    DATA.roads.slice(0, 18).forEach(rd => {
      if (!rd.available) return;
      const a = gx(rd.startJunctionId), b = gx(rd.endJunctionId);
      h += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#343A34" stroke-width="2"/>`;
    });
    DATA.junctions.slice(0, 12).forEach(j => {
      const p = gx(j.id);
      const c = API.junctionCongestion(j.id);
      h += `<circle cx="${p.x}" cy="${p.y}" r="5" fill="${congColor(c)}"/>`;
      h += `<text x="${p.x+8}" y="${p.y+4}" fill="#747B73" font-size="10" font-family="monospace">${j.id}</text>`;
    });
    // highlight route
    const hl = [["J-07","J-08"],["J-08","J-09"],["J-09","J-10"]];
    hl.forEach(([f,t]) => { const a=gx(f),b=gx(t); h += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#8DCBFA" stroke-width="4"/>`; });
    r.innerHTML = h;

    const t = $("scTransit");
    let ht = "";
    const b01 = DATA.busRoutes[0].stops;
    for (let i = 0; i < b01.length; i++) {
      const x = 30 + i * 50, y = 120;
      ht += `<circle cx="${x}" cy="${y}" r="7" fill="#8DCBFA"/>`;
      ht += `<text x="${x}" y="${y+22}" fill="#747B73" font-size="9" text-anchor="middle" font-family="monospace">${b01[i].junctionId}</text>`;
      if (i < b01.length - 1) {
        ht += `<line x1="${x}" y1="${y}" x2="${x+50}" y2="${y}" stroke="#8DCBFA" stroke-width="3"/>`;
      }
    }
    t.innerHTML = ht;
  }

  /* ---------- FAQ accordion ---------- */
  function initFaq() {
    document.querySelectorAll(".faq-q").forEach(q => {
      q.addEventListener("click", () => {
        const item = q.parentElement;
        item.classList.toggle("open");
      });
    });
  }

  /* ---------- Mobile menu ---------- */
  function initMenu() {
    const tog = $("menuToggle"), links = $("navLinks");
    tog.addEventListener("click", () => links.classList.toggle("open"));
    links.querySelectorAll("a").forEach(a => a.addEventListener("click", () => links.classList.remove("open")));
  }

  /* ---------- Init ---------- */
  document.addEventListener("DOMContentLoaded", () => {
    drawHeroNet();
    renderCaps();
    renderDashPreview();
    fillRouteSelects();
    renderTransport();
    renderIncidents();
    renderCharts();
    drawShowcase();
    initFaq();
    initMenu();
    $("rpCalc").addEventListener("click", calcRoute);
    setInterval(() => {
      const now = new Date();
      const el = $("dpTime");
      if (el) el.textContent = now.toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" }) + " · SIMULATED";
    }, 30000);
  });
})();
