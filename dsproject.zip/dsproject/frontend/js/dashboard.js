/* SMART CITY — Dashboard controller */
(function () {
  const $ = id => document.getElementById(id);
  const jpos = {};
  DATA.junctions.forEach(j => jpos[j.id] = j);

  const congColor = c => c < 0.25 ? "#75D6A0" : c < 0.5 ? "#E8C46A" : c < 0.75 ? "#F09A64" : "#F16F6F";
  const stateLabel = s => s.split("_").map(w => w[0] + w.slice(1).toLowerCase()).join(" ");

  /* ============ Map ============ */
  let map, roadLayer = L.layerGroup(), junctionLayer = L.layerGroup(), incidentLayer = L.layerGroup(), busLayer = L.layerGroup(), routeLayer = L.layerGroup();
  let currentLayer = "all";

  function initMap() {
    map = L.map("map", { zoomControl: true }).setView([40.721, -74.000], 14);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors", maxZoom: 19
    }).addTo(map);
    roadLayer.addTo(map); junctionLayer.addTo(map); incidentLayer.addTo(map); busLayer.addTo(map); routeLayer.addTo(map);
    drawRoads(); drawJunctions(); drawIncidents(); drawBuses();
  }

  function roadColor(r) {
    if (!r.available) return "#555";
    if (currentLayer === "congestion") return congColor(r.congestionLevel);
    return "#4a5568";
  }

  function drawRoads() {
    roadLayer.clearLayers();
    DATA.roads.forEach(r => {
      const a = jpos[r.startJunctionId], b = jpos[r.endJunctionId];
      if (!a || !b) return;
      const line = L.polyline([[a.lat, a.lon], [b.lat, b.lon]], {
        color: roadColor(r), weight: r.available ? 4 : 2,
        opacity: r.available ? 0.9 : 0.3, dashArray: r.available ? null : "6 6"
      });
      line.bindPopup(`<b>${r.id}</b> — ${r.name}<br>Distance: ${r.distanceKm} km<br>Limit: ${r.speedLimitKmh} km/h<br>Congestion: ${(r.congestionLevel*100).toFixed(0)}%${r.available ? "" : "<br><span style='color:#F16F6F'>CLOSED</span>"}`);
      roadLayer.addLayer(line);
    });
  }

  function drawJunctions() {
    junctionLayer.clearLayers();
    DATA.junctions.forEach(j => {
      const c = API.junctionCongestion(j.id);
      const marker = L.circleMarker([j.lat, j.lon], {
        radius: 7, color: "#101110", weight: 2, fillColor: congColor(c), fillOpacity: 1
      });
      marker.bindPopup(`<b>${j.id}</b> — ${j.name}<br>Congestion: ${(c*100).toFixed(0)}%<br>State: ${stateLabel(API.trafficState(c))}`);
      marker.on("click", () => showJunctionDetail(j.id));
      junctionLayer.addLayer(marker);
    });
  }

  function drawIncidents() {
    incidentLayer.clearLayers();
    DATA.incidents.forEach(inc => {
      const j = jpos[inc.junctionId];
      if (!j) return;
      const icon = L.divIcon({
        html: `<div style="background:#F16F6F;color:#101110;font-family:monospace;font-size:10px;font-weight:bold;padding:2px 6px;border-radius:3px;white-space:nowrap;">⚠ ${inc.id}</div>`,
        className: "", iconSize: [60, 18]
      });
      const m = L.marker([j.lat, j.lon], { icon });
      m.bindPopup(`<b>${inc.id}</b> — ${stateLabel(inc.type)}<br>Severity: ${inc.severity}<br>${inc.description}`);
      incidentLayer.addLayer(m);
    });
  }

  function drawBuses() {
    busLayer.clearLayers();
    DATA.busRoutes.forEach(rt => {
      const pts = rt.stops.map(s => { const j = jpos[s.junctionId]; return j ? [j.lat, j.lon] : null; }).filter(Boolean);
      if (pts.length < 2) return;
      const line = L.polyline(pts, { color: rt.color, weight: 4, opacity: 0.85 });
      line.bindPopup(`<b>${rt.id}</b> — ${rt.name}<br>${rt.stops.length} stops`);
      busLayer.addLayer(line);
      rt.stops.forEach((s, i) => {
        const j = jpos[s.junctionId];
        if (!j) return;
        const dot = L.circleMarker([j.lat, j.lon], { radius: 4, color: rt.color, fillColor: rt.color, fillOpacity: 1, weight: 2 });
        dot.bindPopup(`${rt.id} — Stop ${i+1}: ${s.name}`);
        busLayer.addLayer(dot);
      });
    });
  }

  function applyLayer(layer) {
    currentLayer = layer;
    document.querySelectorAll(".map-btn[data-layer]").forEach(b => b.classList.toggle("active", b.dataset.layer === layer));
    if (layer === "all") { roadLayer.addTo(map); junctionLayer.addTo(map); incidentLayer.addTo(map); busLayer.addTo(map); }
    else if (layer === "congestion") { roadLayer.addTo(map); junctionLayer.addTo(map); incidentLayer.remove(); busLayer.remove(); }
    else if (layer === "incidents") { roadLayer.remove(); junctionLayer.remove(); incidentLayer.addTo(map); busLayer.remove(); }
    else if (layer === "buses") { roadLayer.remove(); junctionLayer.remove(); incidentLayer.remove(); busLayer.addTo(map); }
    drawRoads(); drawJunctions();
  }

  function highlightRoute(junctions) {
    routeLayer.clearLayers();
    const pts = junctions.map(jid => { const j = jpos[jid]; return j ? [j.lat, j.lon] : null; }).filter(Boolean);
    if (pts.length > 1) {
      L.polyline(pts, { color: "#8DCBFA", weight: 6, opacity: 0.9 }).addTo(routeLayer);
      map.fitBounds(L.latLngBounds(pts).pad(0.2));
    }
  }

  /* ============ Junction detail ============ */
  function showJunctionDetail(jid) {
    const j = jpos[jid];
    const c = API.junctionCongestion(jid);
    const roads = DATA.roads.filter(r => r.startJunctionId === jid || r.endJunctionId === jid);
    const incs = DATA.incidents.filter(i => i.junctionId === jid);
    let speed = 0; roads.forEach(r => speed += r.speedLimitKmh * (1 - r.congestionLevel));
    speed = roads.length ? Math.round(speed / roads.length) : 0;
    $("junctionDetail").innerHTML = `
      <h3>${j.id} — ${j.name}</h3>
      <div class="detail-row"><span class="k">State</span><span style="color:${congColor(c)}">${stateLabel(API.trafficState(c))}</span></div>
      <div class="detail-row"><span class="k">Congestion</span><span>${(c*100).toFixed(0)}%</span></div>
      <div class="detail-row"><span class="k">Avg Speed</span><span>${speed} km/h</span></div>
      <div class="detail-row"><span class="k">Density</span><span>${(Math.min(1, c*1.1)*100).toFixed(0)}%</span></div>
      <div class="detail-row"><span class="k">Connected Roads</span><span>${roads.length}</span></div>
      <div class="detail-row"><span class="k">Nearby Incidents</span><span>${incs.length}</span></div>
      <div style="margin-top:16px;"><div class="mono muted" style="margin-bottom:8px;">CONNECTED ROADS</div>
        ${roads.map(r => `<div class="detail-row"><span class="k">${r.id}</span><span>${r.startJunctionId}↔${r.endJunctionId} · ${r.distanceKm}km ${r.available?"":"· CLOSED"}</span></div>`).join("")}
      </div>`;
  }

  /* ============ KPIs & Events ============ */
  async function refreshKpis() {
    const kpis = await API.getKpis();
    const incs = await API.getIncidents();
    const routes = await API.getBusRoutes();
    $("kpiStrip").innerHTML = `
      <div class="kpi"><div class="k-l">Avg Speed</div><div class="k-v">${kpis.averageSpeedKmh}</div><div class="k-d">km/h · simulated</div></div>
      <div class="kpi"><div class="k-l">Congested Junctions</div><div class="k-v">${kpis.congestedJunctions}</div><div class="k-d">of ${kpis.totalJunctions}</div></div>
      <div class="kpi"><div class="k-l">Active Incidents</div><div class="k-v">${incs.filter(i => i.status !== "RESOLVED").length}</div><div class="k-d">${incs.length} total</div></div>
      <div class="kpi"><div class="k-l">Active Buses</div><div class="k-v">${routes.length * 4.5 | 0}</div><div class="k-d">${routes.length} routes · sim</div></div>`;
  }

  async function refreshEvents() {
    const incs = await API.getPriorityIncidents();
    const events = [];
    incs.forEach(i => events.push({ time: i.reportedTime, text: `${i.severity} ${stateLabel(i.type)} at ${i.junctionId}`, type: "incident" }));
    DATA.roads.filter(r => !r.available).forEach(r => events.push({ time: new Date(Date.now()-3600000).toISOString(), text: `${r.id} restricted (closed)`, type: "road" }));
    // route-calculated event
    events.push({ time: new Date(Date.now()-120000).toISOString(), text: "Emergency route calculated for INC-001", type: "route" });
    events.push({ time: new Date(Date.now()-60000).toISOString(), text: "B-03 schedule updated", type: "bus" });
    events.sort((a, b) => new Date(b.time) - new Date(a.time));
    $("eventsList").innerHTML = events.slice(0, 8).map(e => `
      <div class="event-item">
        <div class="e-time">${new Date(e.time).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</div>
        <div>${e.text}</div>
      </div>`).join("");
  }

  /* ============ Views ============ */
  const VIEWS = {
    overview: "Overview", traffic: "Live Traffic", routes: "Route Planner",
    transport: "Public Transport", incidents: "Incidents", "road-network": "Road Network",
    analytics: "Analytics", settings: "Settings"
  };

  function switchView(v) {
    document.querySelectorAll(".view-section").forEach(s => s.classList.remove("active"));
    const sec = $("view-" + v);
    if (sec) sec.classList.add("active");
    document.querySelectorAll(".sb-link").forEach(l => l.classList.toggle("active", l.dataset.view === v));
    $("viewTitle").textContent = VIEWS[v] || "Overview";
    window.location.hash = v;
    if (v === "analytics") renderAnalyticsCharts();
    if (v === "traffic") renderTrafficTable();
    if (v === "incidents") renderIncidentTable();
    if (v === "transport") renderTransport();
    if (v === "road-network") renderRoadNetwork();
    if (v === "settings") checkApiState();
    setTimeout(() => map && map.invalidateSize(), 100);
  }

  /* ---------- Traffic view ---------- */
  async function renderTrafficTable() {
    const statuses = await API.getJunctionStatuses();
    const f = $("trafficFilter").value;
    const rows = statuses.filter(s => !f || s.state === f);
    $("trafficTable").querySelector("tbody").innerHTML = rows.map(s => `
      <tr style="cursor:pointer" data-jid="${s.id}">
        <td class="mono">${s.id}</td><td>${s.name}</td>
        <td><span style="color:${congColor(s.congestion)}">${stateLabel(s.state)}</span></td>
        <td>${(s.congestion*100).toFixed(0)}%</td><td>${s.averageSpeedKmh} km/h</td>
      </tr>`).join("");
    $("trafficTable").querySelectorAll("tbody tr").forEach(tr => {
      tr.addEventListener("click", () => {
        const jid = tr.dataset.jid; const j = jpos[jid];
        const c = API.junctionCongestion(jid);
        const roads = DATA.roads.filter(r => r.startJunctionId === jid || r.endJunctionId === jid);
        let sp = 0; roads.forEach(r => sp += r.speedLimitKmh * (1 - r.congestionLevel));
        sp = roads.length ? Math.round(sp / roads.length) : 0;
        $("trafficDetail").innerHTML = `
          <h3>${jid} — ${j.name}</h3>
          <div class="detail-row"><span class="k">State</span><span style="color:${congColor(c)}">${stateLabel(API.trafficState(c))}</span></div>
          <div class="detail-row"><span class="k">Congestion</span><span>${(c*100).toFixed(0)}%</span></div>
          <div class="detail-row"><span class="k">Avg Speed</span><span>${sp} km/h</span></div>
          <div class="detail-row"><span class="k">Connected Roads</span><span>${roads.length}</span></div>
          <div style="margin-top:16px;">${roads.map(r => `<div class="detail-row"><span class="k">${r.id}</span><span>${r.distanceKm}km · ${r.speedLimitKmh}km/h ${r.available?"":"· CLOSED"}</span></div>`).join("")}</div>`;
      });
    });
  }

  /* ---------- Routes view ---------- */
  function fillRouteSelects() {
    const opts = DATA.junctions.map(j => `<option value="${j.id}">${j.id} — ${j.name}</option>`).join("");
    $("rSource").innerHTML = opts; $("rDest").innerHTML = opts;
    $("rSource").value = "J-01"; $("rDest").value = "J-24";
  }
  async function calcRoute() {
    const s = $("rSource").value, d = $("rDest").value, m = $("rMode").value;
    const r = await API.calculateRoute(s, d, m);
    if (!r.reachable) {
      $("rResult").innerHTML = `<h3>Route Unavailable</h3><p style="color:var(--critical);margin-top:8px;">${r.reason}</p>`;
      return;
    }
    highlightRoute(r.junctions);
    const path = r.junctions.map(jid => { const j = jpos[jid]; return `<span title="${j?j.name:""}">${jid}</span>`; }).join(" → ");
    const alts = (r.alternatives || []).map(a => `
      <div class="detail-row"><span class="k">${a.mode}</span><span>${a.totalDistanceKm.toFixed(1)} km · ${a.totalTimeMinutes.toFixed(1)} min</span></div>`).join("");
    $("rResult").innerHTML = `
      <p class="mono muted" style="margin-bottom:12px;">${r.reason}</p>
      <div class="rp-metrics">
        <div class="m"><div class="v">${r.totalDistanceKm.toFixed(1)}</div><div class="l">Distance (km)</div></div>
        <div class="m"><div class="v">${r.totalTimeMinutes.toFixed(1)}</div><div class="l">Est. Time (min)</div></div>
        <div class="m"><div class="v">${r.junctions.length}</div><div class="l">Junctions</div></div>
      </div>
      <div class="rp-path">${path}</div>
      ${alts ? `<div style="margin-top:24px;padding-top:20px;border-top:1px solid var(--border);"><h4 style="margin-bottom:12px;">Alternatives</h4>${alts}</div>` : ""}`;
  }

  /* ---------- Transport view ---------- */
  async function renderTransport() {
    const routes = await API.getBusRoutes();
    const q = ($("tSearch").value || "").toLowerCase();
    const filtered = routes.filter(r =>
      !q || r.id.toLowerCase().includes(q) || r.name.toLowerCase().includes(q) ||
      r.stopNames.some(n => n.toLowerCase().includes(q)));
    $("tGrid").innerHTML = filtered.map(r => `
      <div class="route-card" data-route="${r.id}">
        <div class="rhead"><span class="rid" style="color:${r.color}">${r.id}</span><span class="badge ${r.status==='ON_TIME'?'b-low':'b-medium'}">${r.status.replace("_"," ")}</span></div>
        <div class="rname">${r.name}</div>
        <div class="rmeta"><span>${r.stopCount} stops</span><span>${r.durationMinutes} min</span><span>Next: ${r.nextArrival}</span></div>
        <div class="route-stops">${r.stopNames.map((s,i) => `<div style="padding:4px 0">${i+1}. ${s}</div>`).join("")}</div>
      </div>`).join("");
    document.querySelectorAll("#tGrid .route-card").forEach(card => {
      card.addEventListener("click", () => {
        const rt = DATA.busRoutes.find(r => r.id === card.dataset.route);
        card.classList.toggle("expanded");
        if (rt) {
          const ids = rt.stops.map(s => s.junctionId);
          highlightRoute(ids);
        }
      });
    });
  }

  /* ---------- Incidents view ---------- */
  function fillIncidentJunctionSelect() {
    $("iJunction").innerHTML = DATA.junctions.map(j => `<option value="${j.id}">${j.id} — ${j.name}</option>`).join("");
  }
  async function renderIncidentTable() {
    let incs = await API.getIncidents();
    const ft = $("iFilterType").value, fs = $("iFilterSev").value, sort = $("iSort").value;
    if (ft) incs = incs.filter(i => i.type === ft);
    if (fs) incs = incs.filter(i => i.severity === fs);
    if (sort === "priority") incs = API.prioritySort ? API.prioritySort(incs) : incs;
    else incs = incs.slice().sort((a, b) => new Date(b.reportedTime) - new Date(a.reportedTime));
    const typeLabel = t => t.split("_").map(w => w[0] + w.slice(1).toLowerCase()).join(" ");
    const sevBadge = s => `b-${s.toLowerCase()}`;
    $("iTable").querySelector("tbody").innerHTML = incs.map((i, idx) => `
      <tr>
        <td class="mono">${idx+1}</td><td class="mono">${i.id}</td><td>${typeLabel(i.type)}</td>
        <td>${i.junctionId}</td><td><span class="badge ${sevBadge(i.severity)}">${i.severity}</span></td>
        <td>${stateLabel(i.status)}</td>
        <td class="mono muted">${new Date(i.reportedTime).toLocaleString([], {month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}</td>
        <td>
          ${i.status !== "RESOLVED" ? `<button class="map-btn" onclick="resolveIncident('${i.id}')">Resolve</button>` : ""}
          <button class="map-btn" onclick="deleteIncident('${i.id}')" style="color:#F16F6F;">Delete</button>
        </td>
      </tr>`).join("") || `<tr><td colspan="8" class="muted" style="text-align:center;padding:24px;">No incidents match the filters.</td></tr>`;
  }
  window.resolveIncident = async id => { await API.updateIncidentStatus(id, "RESOLVED"); renderIncidentTable(); refreshKpis(); refreshEvents(); };
  window.deleteIncident = async id => { if (confirm("Delete incident " + id + "?")) { await API.deleteIncident(id); renderIncidentTable(); refreshKpis(); refreshEvents(); } };

  async function createIncident() {
    const inc = {
      type: $("iType").value, junctionId: $("iJunction").value,
      severity: $("iSeverity").value, description: $("iDesc").value || "No description",
      status: "REPORTED"
    };
    await API.createIncident(inc);
    $("iDesc").value = "";
    renderIncidentTable(); refreshKpis(); refreshEvents(); drawIncidents();
  }

  /* ---------- Road Network view ---------- */
  function renderRoadNetwork() {
    $("jTable").querySelector("tbody").innerHTML = DATA.junctions.map(j => `
      <tr><td class="mono">${j.id}</td><td>${j.name}</td><td>${j.lat.toFixed(5)}</td><td>${j.lon.toFixed(5)}</td></tr>`).join("");
    $("rTable").querySelector("tbody").innerHTML = DATA.roads.map(r => `
      <tr>
        <td class="mono">${r.id}</td><td>${r.name}</td><td class="mono">${r.startJunctionId}</td><td class="mono">${r.endJunctionId}</td>
        <td>${r.distanceKm} km</td><td>${r.speedLimitKmh} km/h</td>
        <td style="color:${congColor(r.congestionLevel)}">${(r.congestionLevel*100).toFixed(0)}%</td>
        <td>${r.available ? '<span style="color:#75D6A0">Open</span>' : '<span style="color:#F16F6F">Closed</span>'}</td>
      </tr>`).join("");
  }

  /* ---------- Analytics ---------- */
  let chartsRendered = false;
  async function renderAnalyticsCharts() {
    if (chartsRendered) return;
    chartsRendered = true;
    Chart.defaults.color = "#A4AAA1"; Chart.defaults.borderColor = "#343A34";
    const cong = await API.getAnalytics("congestion-distribution");
    new Chart($("aCong"), { type: "doughnut", data: { labels: Object.keys(cong), datasets: [{ data: Object.values(cong), backgroundColor: ["#75D6A0","#E8C46A","#F09A64","#F16F6F"], borderWidth: 0 }] }, options: { plugins: { legend: { position: "bottom" } } } });
    const incT = await API.getAnalytics("incidents-by-type");
    new Chart($("aIncType"), { type: "bar", data: { labels: Object.keys(incT), datasets: [{ data: Object.values(incT), backgroundColor: "#C7F36B" }] }, options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } } });
    const spd = (await API.getAnalytics("speed-by-road")).slice(0, 12);
    new Chart($("aSpeed"), { type: "bar", data: { labels: spd.map(r => r.roadId), datasets: [{ label: "Limit", data: spd.map(r => r.speedLimit), backgroundColor: "#343A34" }, { label: "Effective", data: spd.map(r => r.effectiveSpeed), backgroundColor: "#8DCBFA" }] }, options: { plugins: { legend: { position: "bottom" } } } });
    const junc = await API.getAnalytics("most-congested-junctions");
    new Chart($("aJunc"), { type: "bar", data: { labels: junc.map(j => j.id), datasets: [{ data: junc.map(j => +j.congestion.toFixed(2)), backgroundColor: junc.map(j => congColor(j.congestion)) }] }, options: { indexAxis: "y", plugins: { legend: { display: false } }, scales: { x: { max: 1 } } } });
    const sev = await API.getAnalytics("incidents-by-severity");
    new Chart($("aSev"), { type: "bar", data: { labels: Object.keys(sev), datasets: [{ data: Object.values(sev), backgroundColor: ["#75D6A0","#E8C46A","#F09A64","#F16F6F"] }] }, options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } } });
    const dvt = await API.getAnalytics("distance-vs-time");
    const comps = dvt.comparisons;
    new Chart($("aDvT"), { type: "bar", data: { labels: comps.map(c => c.from + "→" + c.to), datasets: [{ label: "Shortest (km)", data: comps.map(c => +c.shortestDistanceKm.toFixed(2)), backgroundColor: "#8DCBFA" }, { label: "Fastest dist (km)", data: comps.map(c => +c.fastestDistanceKm.toFixed(2)), backgroundColor: "#C7F36B" }] }, options: { plugins: { legend: { position: "bottom" } } } });
  }

  /* ---------- Settings ---------- */
  async function checkApiState() {
    const alive = await API.checkBackend();
    $("apiState").textContent = alive ? "Spring Boot (connected)" : "Local fallback (standalone)";
    $("apiState").style.color = alive ? "#75D6A0" : "#E8C46A";
  }

  /* ============ Time ============ */
  function tick() {
    const now = new Date();
    $("simTime").textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) + " · SIM";
    $("lastUpdate").textContent = "Updated " + now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  }

  /* ============ Init ============ */
  document.addEventListener("DOMContentLoaded", () => {
    initMap();
    fillRouteSelects();
    fillIncidentJunctionSelect();
    refreshKpis();
    refreshEvents();
    tick();
    setInterval(tick, 1000);
    setInterval(() => { refreshKpis(); refreshEvents(); }, 30000);

    // Sidebar nav
    document.querySelectorAll(".sb-link").forEach(l => l.addEventListener("click", () => switchView(l.dataset.view)));
    // Map layer buttons
    document.querySelectorAll(".map-btn[data-layer]").forEach(b => b.addEventListener("click", () => applyLayer(b.dataset.layer)));
    $("recenterBtn").addEventListener("click", () => map.setView([40.721, -74.000], 14));
    // Route calc
    $("rCalc").addEventListener("click", calcRoute);
    // Traffic filter
    $("trafficFilter").addEventListener("change", renderTrafficTable);
    // Transport search
    $("tSearch").addEventListener("input", renderTransport);
    // Incident create
    $("iCreate").addEventListener("click", createIncident);
    $("iFilterType").addEventListener("change", renderIncidentTable);
    $("iFilterSev").addEventListener("change", renderIncidentTable);
    $("iSort").addEventListener("change", renderIncidentTable);
    // Mobile sidebar toggle
    $("sbToggle").addEventListener("click", () => $("sidebar").classList.toggle("open"));

    // Hash routing
    const h = window.location.hash.slice(1);
    if (VIEWS[h]) switchView(h);
    window.addEventListener("hashchange", () => {
      const h2 = window.location.hash.slice(1);
      if (VIEWS[h2]) switchView(h2);
    });
  });
})();
