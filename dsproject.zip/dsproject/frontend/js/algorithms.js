/**
 * SMART CITY — Frontend data structures & algorithms.
 * Implements the same graph engine as the Java backend so the dashboard
 * works standalone when the Spring Boot API is unreachable.
 */

/* ---------------- Custom LinkedList (ordered stops) ---------------- */
class LinkedList {
  constructor() { this.head = this.tail = null; this._size = 0; }
  add(v) {
    const n = { value: v, next: null };
    if (!this.head) this.head = this.tail = n;
    else { this.tail.next = n; this.tail = n; }
    this._size++;
  }
  get size() { return this._size; }
  toArray() {
    const out = []; let c = this.head;
    while (c) { out.push(c.value); c = c.next; }
    return out;
  }
  [Symbol.iterator]() {
    let c = this.head;
    return { next: () => {
      if (!c) return { done: true };
      const v = c.value; c = c.next; return { value: v, done: false };
    }};
  }
}

/* ---------------- Max-Heap priority queue ---------------- */
class MaxHeap {
  constructor(cmp) { this.heap = []; this.cmp = cmp; }
  add(v) {
    this.heap.push(v);
    let i = this.heap.length - 1;
    while (i > 0) {
      const p = Math.floor((i - 1) / 2);
      if (this.cmp(this.heap[i], this.heap[p]) > 0) {
        [this.heap[i], this.heap[p]] = [this.heap[p], this.heap[i]];
        i = p;
      } else break;
    }
  }
  poll() {
    if (!this.heap.length) return null;
    const top = this.heap[0];
    const last = this.heap.pop();
    if (this.heap.length) {
      this.heap[0] = last;
      let i = 0;
      while (true) {
        const l = 2*i+1, r = 2*i+2; let best = i;
        if (l < this.heap.length && this.cmp(this.heap[l], this.heap[best]) > 0) best = l;
        if (r < this.heap.length && this.cmp(this.heap[r], this.heap[best]) > 0) best = r;
        if (best === i) break;
        [this.heap[i], this.heap[best]] = [this.heap[best], this.heap[i]];
        i = best;
      }
    }
    return top;
  }
  get size() { return this.heap.length; }
}

/* ---------------- Circular Queue (events) ---------------- */
class CircularQueue {
  constructor(cap) { this.buf = new Array(cap); this.head = this.tail = this._size = 0; this.cap = cap; }
  enqueue(v) {
    if (this._size === this.cap) throw new Error("Queue full");
    this.buf[this.tail] = v; this.tail = (this.tail + 1) % this.cap; this._size++;
  }
  dequeue() {
    if (!this._size) return null;
    const v = this.buf[this.head]; this.buf[this.head] = null;
    this.head = (this.head + 1) % this.cap; this._size--; return v;
  }
  get size() { return this._size; }
  toArray() {
    const out = []; let i = this.head;
    for (let k = 0; k < this._size; k++) { out.push(this.buf[i]); i = (i + 1) % this.cap; }
    return out;
  }
}

/* ---------------- Array Stack ---------------- */
class ArrayStack {
  constructor() { this.s = []; }
  push(v) { this.s.push(v); }
  pop() { return this.s.pop(); }
  peek() { return this.s[this.s.length - 1]; }
  get size() { return this.s.length; }
}

/* ---------------- Weighted Graph (adjacency list) ---------------- */
class Graph {
  constructor() { this.adj = new Map(); }
  addVertex(id) { if (!this.adj.has(id)) this.adj.set(id, []); }
  addRoad(from, to, road) {
    this.addVertex(from); this.addVertex(to);
    const edge = { from, to, roadId: road.id, distanceKm: road.distanceKm,
      timeMinutes: (road.distanceKm / (road.speedLimitKmh * (1 - road.congestionLevel) || 0.1)) * 60,
      congestionLevel: road.congestionLevel, available: road.available };
    this.adj.get(from).push(edge);
    this.adj.get(to).push({ ...edge, from: to, to: from });
  }
  getNeighbors(id) { return (this.adj.get(id) || []).filter(e => e.available); }
  get vertices() { return [...this.adj.keys()]; }
}

/* ---------------- Dijkstra ---------------- */
const Dijkstra = {
  distanceWeight: e => e.distanceKm,
  timeWeight: e => e.timeMinutes,
  // Avoid congestion: cost = time * (1 + 3 * congestionLevel)
  congestionWeight: e => e.timeMinutes * (1 + 3 * e.congestionLevel),

  shortestPath(graph, source, dest, weightFn) {
    if (!graph.adj.has(source) || !graph.adj.has(dest)) {
      return { reachable: false, junctions: [], roadIds: [], distanceKm: 0, timeMinutes: 0 };
    }
    const dist = new Map(), prevJ = new Map(), prevR = new Map(), settled = new Set();
    for (const v of graph.vertices) dist.set(v, Infinity);
    dist.set(source, 0);
    const pq = [[0, source]];
    while (pq.length) {
      pq.sort((a, b) => a[0] - b[0]);
      const [d, u] = pq.shift();
      if (settled.has(u)) continue;
      settled.add(u);
      if (u === dest) break;
      for (const e of graph.getNeighbors(u)) {
        if (settled.has(e.to)) continue;
        const alt = d + weightFn(e);
        if (alt < dist.get(e.to)) {
          dist.set(e.to, alt); prevJ.set(e.to, u); prevR.set(e.to, e.roadId);
          pq.push([alt, e.to]);
        }
      }
    }
    if (!isFinite(dist.get(dest))) {
      return { reachable: false, junctions: [], roadIds: [], distanceKm: 0, timeMinutes: 0 };
    }
    const junctions = [], roadIds = [];
    let cur = dest; junctions.push(cur);
    while (cur !== source) {
      const r = prevR.get(cur); if (r) roadIds.push(r);
      cur = prevJ.get(cur); junctions.push(cur);
    }
    junctions.reverse(); roadIds.reverse();
    // Recompute actual distance & time from edges
    const edgeMap = new Map();
    for (const v of graph.vertices) for (const e of graph.getNeighbors(v)) if (!edgeMap.has(e.roadId)) edgeMap.set(e.roadId, e);
    let distKm = 0, timeMin = 0;
    for (const rid of roadIds) { const e = edgeMap.get(rid); if (e) { distKm += e.distanceKm; timeMin += e.timeMinutes; } }
    return { reachable: true, junctions, roadIds, distanceKm: distKm, timeMinutes: timeMin };
  }
};

/* ---------------- BFS / DFS ---------------- */
const BFS = {
  traverse(graph, start) {
    const order = [], visited = new Set();
    if (!graph.adj.has(start)) return order;
    const q = [start]; visited.add(start);
    while (q.length) {
      const u = q.shift(); order.push(u);
      for (const e of graph.getNeighbors(u)) if (!visited.has(e.to)) { visited.add(e.to); q.push(e.to); }
    }
    return order;
  },
  components(graph) {
    const comps = [], visited = new Set();
    for (const v of graph.vertices) {
      if (!visited.has(v)) {
        const c = BFS.traverse(graph, v); comps.push(c); c.forEach(x => visited.add(x));
      }
    }
    return comps;
  }
};

const DFS = {
  traverse(graph, start) {
    const order = [], visited = new Set();
    if (!graph.adj.has(start)) return order;
    const rec = u => { visited.add(u); order.push(u);
      for (const e of graph.getNeighbors(u)) if (!visited.has(e.to)) rec(e.to); };
    rec(start);
    return order;
  }
};

/* ---------------- Build graph from DATA ---------------- */
function buildGraph(data) {
  const g = new Graph();
  for (const r of data.roads) g.addRoad(r.startJunctionId, r.endJunctionId, r);
  return g;
}

/* ---------------- Next-arrival simulation (deterministic) ---------------- */
function nextArrival(routeId) {
  const HEADWAY = 15;
  const offset = Math.abs(hashStr(routeId)) % HEADWAY;
  const now = new Date();
  const mod = now.getHours() * 60 + now.getMinutes();
  const win = Math.floor(mod / HEADWAY) * HEADWAY;
  let arr = win + offset;
  if (arr <= mod) arr += HEADWAY;
  arr = arr % (24 * 60);
  return String(Math.floor(arr / 60)).padStart(2, "0") + ":" + String(arr % 60).padStart(2, "0");
}
function hashStr(s) { let h = 0; for (let i=0;i<s.length;i++) h = ((h<<5)-h) + s.charCodeAt(i); return h; }
