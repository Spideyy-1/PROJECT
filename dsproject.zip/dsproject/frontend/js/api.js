/**
 * SMART CITY — API client.
 * Tries the Spring Boot backend first; on failure falls back to the local
 * sample dataset and the frontend algorithms so the dashboard always works.
 */
const API = (function () {
  const BASE = "http://localhost:8080/api";
  let backendAlive = null;

  async function fetchJson(url, opts) {
    const res = await fetch(url, opts);
    if (!res.ok) throw new Error("HTTP " + res.status);
    return res.json();
  }

  async function checkBackend() {
    if (backendAlive !== null) return backendAlive;
    try {
      await fetch(BASE + "/junctions", { signal: AbortSignal.timeout(1500) });
      backendAlive = true;
    } catch {
      backendAlive = false;
    }
    return backendAlive;
  }

  // ---- Junctions ----
  async function getJunctions() {
    if (await checkBackend()) return fetchJson(BASE + "/junctions");
    return DATA.junctions;
  }

  // ---- Roads ----
  async function getRoads() {
    if (await checkBackend()) return fetchJson(BASE + "/roads");
    return DATA.roads;
  }

  // ---- Traffic KPIs ----
  async function getKpis() {
    if (await checkBackend()) return fetchJson(BASE + "/traffic/kpis");
    return localKpis();
  }

  function localKpis() {
    let avgSpeed = 0, congested = 0, closed = 0;
    for (const j of DATA.junctions) {
      const roads = DATA.roads.filter(r => r.startJunctionId === j.id || r.endJunctionId === j.id);
      let c = 0, s = 0;
      for (const r of roads) { c += r.congestionLevel; s += r.speedLimitKmh * (1 - r.congestionLevel); }
      const av = roads.length ? s / roads.length : 0;
      avgSpeed += av;
      if (roads.length && c / roads.length >= 0.5) congested++;
    }
    for (const r of DATA.roads) if (!r.available) closed++;
    return {
      averageSpeedKmh: Math.round(avgSpeed / DATA.junctions.length),
      congestedJunctions: congested,
      totalJunctions: DATA.junctions.length,
      totalRoads: DATA.roads.length,
      closedRoads: closed,
      simulated: true
    };
  }

  // ---- Junction traffic status ----
  function junctionCongestion(jid) {
    const roads = DATA.roads.filter(r => r.startJunctionId === jid || r.endJunctionId === jid);
    if (!roads.length) return 0;
    return roads.reduce((s, r) => s + r.congestionLevel, 0) / roads.length;
  }
  function trafficState(c) {
    if (c < 0.25) return "FREE_FLOW";
    if (c < 0.5) return "LIGHT";
    if (c < 0.75) return "MODERATE";
    return "HEAVY";
  }

  async function getJunctionStatuses() {
    if (await checkBackend()) return fetchJson(BASE + "/traffic/junctions");
    return DATA.junctions.map(j => {
      const c = junctionCongestion(j.id);
      const roads = DATA.roads.filter(r => r.startJunctionId === j.id || r.endJunctionId === j.id);
      let s = 0; for (const r of roads) s += r.speedLimitKmh * (1 - r.congestionLevel);
      return {
        id: j.id, name: j.name, lat: j.lat, lon: j.lon,
        congestion: c, state: trafficState(c),
        averageSpeedKmh: Math.round(roads.length ? s / roads.length : 0),
        density: Math.min(1, c * 1.1)
      };
    });
  }

  // ---- Routes ----
  async function calculateRoute(source, destination, mode) {
    if (await checkBackend()) {
      return fetchJson(BASE + "/routes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ source, destination, mode })
      });
    }
    return localRoute(source, destination, mode);
  }

  function localRoute(source, destination, mode) {
    if (source === destination) {
      return { reachable: true, junctions: [source], roadIds: [], totalDistanceKm: 0, totalTimeMinutes: 0,
        mode, reason: "Source and destination are the same junction.", alternatives: [] };
    }
    const g = buildGraph(DATA);
    const wf = mode === "DISTANCE" ? Dijkstra.distanceWeight
              : mode === "TIME" ? Dijkstra.timeWeight
              : Dijkstra.congestionWeight;
    const r = Dijkstra.shortestPath(g, source, destination, wf);
    if (!r.reachable) {
      return { reachable: false, junctions: [], roadIds: [], totalDistanceKm: 0, totalTimeMinutes: 0,
        mode, reason: "Destination is unreachable (roads may be closed).", alternatives: [] };
    }
    const reason = mode === "DISTANCE"
      ? `Shortest path by total distance (${r.distanceKm.toFixed(1)} km).`
      : mode === "TIME"
      ? `Fastest path by estimated time (${r.timeMinutes.toFixed(1)} min), accounting for congestion.`
      : `Route chosen to avoid congested roads (cost = time × (1 + 3 × congestion)).`;
    const alternatives = [];
    for (const m of ["DISTANCE", "TIME", "AVOID_CONGESTION"]) {
      if (m === mode) continue;
      const w = m === "DISTANCE" ? Dijkstra.distanceWeight : m === "TIME" ? Dijkstra.timeWeight : Dijkstra.congestionWeight;
      const a = Dijkstra.shortestPath(g, source, destination, w);
      if (a.reachable) alternatives.push({ mode: m, junctions: a.junctions, totalDistanceKm: a.distanceKm, totalTimeMinutes: a.timeMinutes });
    }
    return { reachable: true, junctions: r.junctions, roadIds: r.roadIds,
      totalDistanceKm: r.distanceKm, totalTimeMinutes: r.timeMinutes, mode, reason, alternatives };
  }

  // ---- Incidents ----
  async function getIncidents() {
    if (await checkBackend()) return fetchJson(BASE + "/incidents");
    return DATA.incidents;
  }
  async function getPriorityIncidents() {
    if (await checkBackend()) return fetchJson(BASE + "/incidents/priority");
    return prioritySort(DATA.incidents);
  }
  function prioritySort(list) {
    const sev = { LOW: 0, MEDIUM: 1, HIGH: 2, CRITICAL: 3 };
    const cmp = (a, b) => sev[b.severity] - sev[a.severity] || new Date(a.reportedTime) - new Date(b.reportedTime);
    const heap = new MaxHeap(cmp);
    list.forEach(i => heap.add(i));
    const out = []; while (heap.size) out.push(heap.poll());
    return out;
  }
  async function createIncident(inc) {
    if (await checkBackend()) return fetchJson(BASE + "/incidents", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(inc)
    });
    const id = "INC-" + String(DATA.incidents.length + 1).padStart(3, "0");
    const full = { ...inc, id, reportedTime: inc.reportedTime || new Date().toISOString(), status: inc.status || "REPORTED" };
    DATA.incidents.push(full);
    return full;
  }
  async function updateIncidentStatus(id, status) {
    if (await checkBackend()) return fetchJson(BASE + "/incidents/" + id + "/status?status=" + status, { method: "PUT" });
    const inc = DATA.incidents.find(i => i.id === id);
    if (inc) inc.status = status;
    return inc;
  }
  async function deleteIncident(id) {
    if (await checkBackend()) return fetch(BASE + "/incidents/" + id, { method: "DELETE" });
    DATA.incidents = DATA.incidents.filter(i => i.id !== id);
    return {};
  }

  // ---- Transport ----
  async function getBusRoutes() {
    if (await checkBackend()) return fetchJson(BASE + "/transport/routes");
    return DATA.busRoutes.map(r => ({
      id: r.id, name: r.name, color: r.color, status: r.status,
      durationMinutes: r.durationMinutes,
      stopNames: r.stops.map(s => s.name),
      stopJunctionIds: r.stops.map(s => s.junctionId),
      stopCount: r.stops.length,
      nextArrival: nextArrival(r.id)
    }));
  }

  // ---- Analytics ----
  async function getAnalytics(endpoint) {
    if (await checkBackend()) return fetchJson(BASE + "/analytics/" + endpoint);
    return localAnalytics(endpoint);
  }
  function localAnalytics(endpoint) {
    switch (endpoint) {
      case "congestion-distribution": {
        const d = { "Free flow": 0, "Light": 0, "Moderate": 0, "Heavy": 0 };
        for (const r of DATA.roads) {
          const s = trafficState(r.congestionLevel);
          if (s === "FREE_FLOW") d["Free flow"]++;
          else if (s === "LIGHT") d["Light"]++;
          else if (s === "MODERATE") d["Moderate"]++;
          else d["Heavy"]++;
        }
        return d;
      }
      case "speed-by-road":
        return DATA.roads.map(r => ({
          roadId: r.id, name: r.name, speedLimit: r.speedLimitKmh,
          effectiveSpeed: Math.round(r.speedLimitKmh * (1 - r.congestionLevel))
        }));
      case "incidents-by-type": {
        const types = ["ROAD_ACCIDENT","VEHICLE_BREAKDOWN","ROAD_CLOSURE","HEAVY_CONGESTION","EMERGENCY_VEHICLE_REQUEST"];
        const d = {}; types.forEach(t => d[t] = 0);
        DATA.incidents.forEach(i => d[i.type]++);
        return d;
      }
      case "incidents-by-severity": {
        const d = {}; ["LOW","MEDIUM","HIGH","CRITICAL"].forEach(s => d[s] = 0);
        DATA.incidents.forEach(i => d[i.severity]++);
        return d;
      }
      case "most-congested-junctions":
        return DATA.junctions.map(j => ({ id: j.id, name: j.name, congestion: junctionCongestion(j.id) }))
          .sort((a, b) => b.congestion - a.congestion).slice(0, 10);
      case "road-utilization": {
        let open = 0, closed = 0, ac = 0;
        for (const r of DATA.roads) { if (r.available) open++; else closed++; ac += r.congestionLevel; }
        return { total: DATA.roads.length, open, closed, averageCongestion: DATA.roads.length ? ac / DATA.roads.length : 0 };
      }
      case "incidents-over-time": {
        const buckets = [0, 4, 8, 12, 16, 20];
        const series = {};
        buckets.forEach(b => { series[b] = { LOW: 0, MEDIUM: 0, HIGH: 0, CRITICAL: 0 }; });
        for (const i of DATA.incidents) {
          const h = new Date(i.reportedTime).getHours();
          const b = Math.floor(h / 4) * 4;
          series[b][i.severity]++;
        }
        return { buckets, series };
      }
      case "distance-vs-time": {
        const pairs = [["J-01","J-24"],["J-01","J-12"],["J-07","J-18"],["J-19","J-06"]];
        const g = buildGraph(DATA);
        return { comparisons: pairs.map(([f, t]) => {
          const d = Dijkstra.shortestPath(g, f, t, Dijkstra.distanceWeight);
          const tm = Dijkstra.shortestPath(g, f, t, Dijkstra.timeWeight);
          return { from: f, to: t, shortestDistanceKm: d.distanceKm, fastestTimeMin: tm.timeMinutes, fastestDistanceKm: tm.distanceKm };
        })};
      }
      default: return {};
    }
  }

  // ---- Graph traversal ----
  async function getBfs(start) {
    if (await checkBackend()) return fetchJson(BASE + "/graph/bfs?start=" + start);
    return BFS.traverse(buildGraph(DATA), start);
  }
  async function getDfs(start) {
    if (await checkBackend()) return fetchJson(BASE + "/graph/dfs?start=" + start);
    return DFS.traverse(buildGraph(DATA), start);
  }

  return {
    checkBackend, getJunctions, getRoads, getKpis, getJunctionStatuses,
    junctionCongestion, trafficState, calculateRoute,
    getIncidents, getPriorityIncidents, createIncident, updateIncidentStatus, deleteIncident,
    getBusRoutes, getAnalytics, getBfs, getDfs
  };
})();
