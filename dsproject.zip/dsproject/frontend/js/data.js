/**
 * SMART CITY — Shared sample dataset.
 * Mirrors the Spring Boot seed data (24 junctions, 42 roads, 4 bus routes,
 * 3 incidents). All values are illustrative demo data for an academic
 * simulation — not connected to live traffic or emergency services.
 */
const DATA = (function () {
  const LONS = [-74.010, -74.006, -74.002, -73.998, -73.994, -73.990];
  const LATS = [40.730, 40.724, 40.718, 40.712];
  const NAMES = [
    "Northgate","Oak Avenue","Park Square","Museum","Eastgate","Harbour View",
    "Civic Center","Central Station","City Hall","Library","Plaza","Market Square",
    "University","Technology Park","Riverside","City Hospital","Stadium","Arts District",
    "West Terminal","Industrial Zone","Southgate","Depot","Airport Link","South Harbour"
  ];

  const junctions = [];
  let idx = 0;
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 6; c++) {
      const id = "J-" + String(idx + 1).padStart(2, "0");
      junctions.push({ id, name: NAMES[idx], lat: LATS[r], lon: LONS[c] });
      idx++;
    }
  }

  const roads = [];
  let rid = 1;
  // Horizontal roads (20)
  const hCong = [
    [0.1,0.3,0.6,0.2,0.4],
    [0.5,0.7,0.3,0.2,0.6],
    [0.4,0.8,0.5,0.3,0.2],
    [0.2,0.6,0.4,0.3,0.5]
  ];
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 5; c++) {
      const from = "J-" + String(r*6 + c + 1).padStart(2,"0");
      const to = "J-" + String(r*6 + c + 2).padStart(2,"0");
      roads.push({
        id: "R-" + String(rid++).padStart(2,"0"),
        startJunctionId: from, endJunctionId: to,
        distanceKm: 0.5, speedLimitKmh: 50, available: true,
        congestionLevel: hCong[r][c],
        name: "Corridor " + (r+1) + " · Segment " + (c+1)
      });
    }
  }
  // Vertical roads (18)
  const vCong = [0.3,0.5,0.7,0.4,0.6,0.3,0.5,0.8,0.4,0.3,0.6,0.5,0.4,0.7,0.3,0.2,0.5,0.6];
  let vi = 0;
  for (let c = 0; c < 6; c++) {
    for (let r = 0; r < 3; r++) {
      const from = "J-" + String(r*6 + c + 1).padStart(2,"0");
      const to = "J-" + String((r+1)*6 + c + 1).padStart(2,"0");
      roads.push({
        id: "R-" + String(rid++).padStart(2,"0"),
        startJunctionId: from, endJunctionId: to,
        distanceKm: 0.7, speedLimitKmh: 40, available: true,
        congestionLevel: vCong[vi++],
        name: "Avenue " + (c+1) + " · Link " + (r+1)
      });
    }
  }
  // Diagonal roads (4)
  const diagonals = [["J-01","J-08"],["J-08","J-15"],["J-15","J-22"],["J-09","J-14"]];
  const dCong = [0.2,0.4,0.3,0.5];
  for (let i = 0; i < diagonals.length; i++) {
    roads.push({
      id: "R-" + String(rid++).padStart(2,"0"),
      startJunctionId: diagonals[i][0], endJunctionId: diagonals[i][1],
      distanceKm: 0.9, speedLimitKmh: 60, available: true,
      congestionLevel: dCong[i],
      name: "Diagonal Link " + (i+1)
    });
  }
  // Close one road (R-19)
  roads.find(r => r.id === "R-19").available = false;

  const now = new Date();
  const minsAgo = m => new Date(now.getTime() - m*60000).toISOString();
  const incidents = [
    { id:"INC-001", type:"ROAD_ACCIDENT", junctionId:"J-04", severity:"HIGH",
      description:"Collision reported near Museum junction.",
      reportedTime: minsAgo(15), status:"IN_PROGRESS", assignedUnit:"Unit A-12" },
    { id:"INC-002", type:"HEAVY_CONGESTION", junctionId:"J-12", severity:"MEDIUM",
      description:"Build-up of traffic approaching Market Square.",
      reportedTime: minsAgo(42), status:"REPORTED", assignedUnit:null },
    { id:"INC-003", type:"VEHICLE_BREAKDOWN", junctionId:"J-20", severity:"LOW",
      description:"Broken-down vehicle on Industrial Zone link.",
      reportedTime: minsAgo(8), status:"REPORTED", assignedUnit:null }
  ];

  const busRoutes = [
    { id:"B-01", name:"Central Station to University", color:"#8DCBFA", status:"ON_TIME", durationMinutes:22,
      stops:[
        {junctionId:"J-08", name:"Central Station"},{junctionId:"J-09", name:"City Hall"},
        {junctionId:"J-10", name:"Library"},{junctionId:"J-16", name:"City Hospital"},
        {junctionId:"J-15", name:"Riverside"},{junctionId:"J-14", name:"Technology Park"},
        {junctionId:"J-13", name:"University"}
      ]},
    { id:"B-02", name:"Civic Center to Riverside", color:"#C7F36B", status:"ON_TIME", durationMinutes:14,
      stops:[
        {junctionId:"J-07", name:"Civic Center"},{junctionId:"J-08", name:"Central Station"},
        {junctionId:"J-14", name:"Technology Park"},{junctionId:"J-15", name:"Riverside"}
      ]},
    { id:"B-03", name:"Technology Park to City Hospital", color:"#E8C46A", status:"DELAYED", durationMinutes:12,
      stops:[
        {junctionId:"J-14", name:"Technology Park"},{junctionId:"J-08", name:"Central Station"},
        {junctionId:"J-09", name:"City Hall"},{junctionId:"J-10", name:"Library"},
        {junctionId:"J-16", name:"City Hospital"}
      ]},
    { id:"B-04", name:"North Terminal to Market Square", color:"#F09A64", status:"ON_TIME", durationMinutes:18,
      stops:[
        {junctionId:"J-01", name:"North Terminal"},{junctionId:"J-07", name:"Civic Center"},
        {junctionId:"J-08", name:"Central Station"},{junctionId:"J-09", name:"City Hall"},
        {junctionId:"J-10", name:"Library"},{junctionId:"J-11", name:"Plaza"},
        {junctionId:"J-12", name:"Market Square"}
      ]}
  ];

  const vehicles = [
    { id:1, type:"CAR", currentJunctionId:"J-01" },
    { id:2, type:"BUS", currentJunctionId:"J-08" },
    { id:3, type:"EMERGENCY", currentJunctionId:"J-14" },
    { id:4, type:"TRUCK", currentJunctionId:"J-16" },
    { id:5, type:"CAR", currentJunctionId:"J-22" },
    { id:6, type:"CAR", currentJunctionId:"J-04" },
    { id:7, type:"BUS", currentJunctionId:"J-12" },
    { id:8, type:"TRUCK", currentJunctionId:"J-20" }
  ];

  return { junctions, roads, incidents, busRoutes, vehicles };
})();

if (typeof module !== "undefined") module.exports = DATA;
